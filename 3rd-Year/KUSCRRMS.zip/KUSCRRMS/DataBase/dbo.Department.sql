﻿CREATE TABLE [dbo].[Department] (
    [DepartmentCode] VARCHAR (50)  NOT NULL,
    [DepartmentName] NVARCHAR (70) NOT NULL,
    [DepartmentHead] NCHAR (70)    NOT NULL,
    PRIMARY KEY CLUSTERED ([DepartmentCode] ASC)
);

