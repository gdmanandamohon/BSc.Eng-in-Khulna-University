﻿CREATE TABLE [dbo].[Admin]
(
	[AdminID] NVARCHAR(10) NOT NULL PRIMARY KEY, 
    [AdminPassword] NVARCHAR(10) NOT NULL,
)
