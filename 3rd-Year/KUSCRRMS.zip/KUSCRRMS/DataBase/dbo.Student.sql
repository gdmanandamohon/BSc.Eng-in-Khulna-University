﻿CREATE TABLE [dbo].[Student]
(
	[ID] NVARCHAR(6) NOT NULL PRIMARY KEY, 
    [FirstName] NVARCHAR(20) NOT NULL, 
    [LastName] NVARCHAR(20) NULL, 
    [MidName] NVARCHAR(20) NULL, 
    [Department] NVARCHAR(70) NOT NULL, 
    [DepartmentCode] VARCHAR(50) NOT NULL, 
    [DateOfBirth] DATE NOT NULL
)


