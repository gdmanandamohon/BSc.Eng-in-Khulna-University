﻿CREATE TABLE [dbo].[PreviousCourse]
(
	[ID] NVARCHAR(6) NOT NULL PRIMARY KEY,
	[CourseCode] NVARCHAR(10) NOT NULL, 
    [CourseTitle] NVARCHAR(100) NOT NULL, 
    [Credit] FLOAT NOT NULL, 
    [Term] NVARCHAR(3) NOT NULL, 
    [Year] NVARCHAR(3) NOT NULL, 
    [Remarks] NCHAR(15) NOT NULL,

)
