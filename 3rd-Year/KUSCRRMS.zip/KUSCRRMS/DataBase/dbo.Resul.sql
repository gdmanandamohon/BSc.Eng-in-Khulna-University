﻿CREATE TABLE [dbo].[Result]
(
	[ID] INT NOT NULL PRIMARY KEY,
	[CourseCode] NVARCHAR(10) NOT NULL, 
    [CourseTitle] NVARCHAR(100) NOT NULL, 
    [Credit] FLOAT NOT NULL, 
	[Attendance] FLOAT NOT NULL,
	[CT1] FLOAT NOT NULL,
	[CT2] FLOAT NOT NULL,
	[CT3] FLOAT NULL,
	[ExamMark] FLOAT NOT NULL,
	[TotalMark] FLOAT NULL,
    [Term] NVARCHAR(3) NOT NULL, 
    [Year] NVARCHAR(3) NOT NULL,
)
