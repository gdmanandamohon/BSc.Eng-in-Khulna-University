﻿namespace KUSCRRMS
{
    partial class LogInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogInForm));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.LogInForm_admin_button = new System.Windows.Forms.Button();
            this.LogInForm_Student_button = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(34, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(334, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Khulna University Result Management Toolkit";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::KUSCRRMS.Properties.Resources.kulogobest;
            this.pictureBox1.Location = new System.Drawing.Point(30, 53);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 131);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // LogInForm_admin_button
            // 
            this.LogInForm_admin_button.Location = new System.Drawing.Point(192, 98);
            this.LogInForm_admin_button.Name = "LogInForm_admin_button";
            this.LogInForm_admin_button.Size = new System.Drawing.Size(75, 34);
            this.LogInForm_admin_button.TabIndex = 2;
            this.LogInForm_admin_button.Text = "Admin";
            this.LogInForm_admin_button.UseVisualStyleBackColor = true;
            this.LogInForm_admin_button.Click += new System.EventHandler(this.LogInForm_admin_button_Click);
            // 
            // LogInForm_Student_button
            // 
            this.LogInForm_Student_button.Location = new System.Drawing.Point(192, 138);
            this.LogInForm_Student_button.Name = "LogInForm_Student_button";
            this.LogInForm_Student_button.Size = new System.Drawing.Size(75, 35);
            this.LogInForm_Student_button.TabIndex = 3;
            this.LogInForm_Student_button.Text = "Student";
            this.LogInForm_Student_button.UseVisualStyleBackColor = true;
            this.LogInForm_Student_button.Click += new System.EventHandler(this.LogInForm_Student_button_Click);
            // 
            // LogInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 207);
            this.Controls.Add(this.LogInForm_Student_button);
            this.Controls.Add(this.LogInForm_admin_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Garamond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(430, 258);
            this.Name = "LogInForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "User Log In";
            this.Load += new System.EventHandler(this.LogInForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button LogInForm_admin_button;
        private System.Windows.Forms.Button LogInForm_Student_button;
    }
}

