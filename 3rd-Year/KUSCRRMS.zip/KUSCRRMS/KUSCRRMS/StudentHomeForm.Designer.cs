﻿namespace KUSCRRMS
{
    partial class StudentHomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(StudentHomeForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StudentHomeForm_exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registerForThisTermToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resultProcessingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showYourResultToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.StudentHomeForm_ID_label = new System.Windows.Forms.Label();
            this.StudentHomeForm_Name_label = new System.Windows.Forms.Label();
            this.StudentHomeForm_Discipline_label = new System.Windows.Forms.Label();
            this.StudentHomeForm_Email_label = new System.Windows.Forms.Label();
            this.StudentHomeForm_CellNo_label = new System.Windows.Forms.Label();
            this.StudentHomeForm_DateOfBirth_label = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.reistrationToolStripMenuItem,
            this.resultProcessingToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.StudentHomeForm_exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // StudentHomeForm_exitToolStripMenuItem
            // 
            this.StudentHomeForm_exitToolStripMenuItem.Name = "StudentHomeForm_exitToolStripMenuItem";
            this.StudentHomeForm_exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.StudentHomeForm_exitToolStripMenuItem.Text = "Exit";
            this.StudentHomeForm_exitToolStripMenuItem.Click += new System.EventHandler(this.StudentHomeForm_exitToolStripMenuItem_Click);
            // 
            // reistrationToolStripMenuItem
            // 
            this.reistrationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registerForThisTermToolStripMenuItem});
            this.reistrationToolStripMenuItem.Name = "reistrationToolStripMenuItem";
            this.reistrationToolStripMenuItem.Size = new System.Drawing.Size(75, 20);
            this.reistrationToolStripMenuItem.Text = "Reistration";
            // 
            // registerForThisTermToolStripMenuItem
            // 
            this.registerForThisTermToolStripMenuItem.Name = "registerForThisTermToolStripMenuItem";
            this.registerForThisTermToolStripMenuItem.Size = new System.Drawing.Size(192, 22);
            this.registerForThisTermToolStripMenuItem.Text = "Register For This Term";
            // 
            // resultProcessingToolStripMenuItem
            // 
            this.resultProcessingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showYourResultToolStripMenuItem});
            this.resultProcessingToolStripMenuItem.Name = "resultProcessingToolStripMenuItem";
            this.resultProcessingToolStripMenuItem.Size = new System.Drawing.Size(111, 20);
            this.resultProcessingToolStripMenuItem.Text = "Result Processing";
            // 
            // showYourResultToolStripMenuItem
            // 
            this.showYourResultToolStripMenuItem.Name = "showYourResultToolStripMenuItem";
            this.showYourResultToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.showYourResultToolStripMenuItem.Text = "Show Your Result";
            this.showYourResultToolStripMenuItem.Click += new System.EventHandler(this.showYourResultToolStripMenuItem_Click);
            // 
            // StudentHomeForm_ID_label
            // 
            this.StudentHomeForm_ID_label.AutoSize = true;
            this.StudentHomeForm_ID_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_ID_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_ID_label.Location = new System.Drawing.Point(138, 149);
            this.StudentHomeForm_ID_label.Name = "StudentHomeForm_ID_label";
            this.StudentHomeForm_ID_label.Size = new System.Drawing.Size(55, 25);
            this.StudentHomeForm_ID_label.TabIndex = 1;
            this.StudentHomeForm_ID_label.Text = "ID : ";
            // 
            // StudentHomeForm_Name_label
            // 
            this.StudentHomeForm_Name_label.AutoSize = true;
            this.StudentHomeForm_Name_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_Name_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_Name_label.Location = new System.Drawing.Point(137, 182);
            this.StudentHomeForm_Name_label.Name = "StudentHomeForm_Name_label";
            this.StudentHomeForm_Name_label.Size = new System.Drawing.Size(86, 25);
            this.StudentHomeForm_Name_label.TabIndex = 2;
            this.StudentHomeForm_Name_label.Text = "Name :";
            this.StudentHomeForm_Name_label.Click += new System.EventHandler(this.StudentHomeForm_Name_label_Click);
            // 
            // StudentHomeForm_Discipline_label
            // 
            this.StudentHomeForm_Discipline_label.AutoSize = true;
            this.StudentHomeForm_Discipline_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_Discipline_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_Discipline_label.Location = new System.Drawing.Point(136, 213);
            this.StudentHomeForm_Discipline_label.Name = "StudentHomeForm_Discipline_label";
            this.StudentHomeForm_Discipline_label.Size = new System.Drawing.Size(136, 25);
            this.StudentHomeForm_Discipline_label.TabIndex = 3;
            this.StudentHomeForm_Discipline_label.Text = "Discipline : ";
            // 
            // StudentHomeForm_Email_label
            // 
            this.StudentHomeForm_Email_label.AutoSize = true;
            this.StudentHomeForm_Email_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_Email_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_Email_label.Location = new System.Drawing.Point(135, 248);
            this.StudentHomeForm_Email_label.Name = "StudentHomeForm_Email_label";
            this.StudentHomeForm_Email_label.Size = new System.Drawing.Size(79, 25);
            this.StudentHomeForm_Email_label.TabIndex = 4;
            this.StudentHomeForm_Email_label.Text = "E-Mail";
            // 
            // StudentHomeForm_CellNo_label
            // 
            this.StudentHomeForm_CellNo_label.AutoSize = true;
            this.StudentHomeForm_CellNo_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_CellNo_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_CellNo_label.Location = new System.Drawing.Point(134, 283);
            this.StudentHomeForm_CellNo_label.Name = "StudentHomeForm_CellNo_label";
            this.StudentHomeForm_CellNo_label.Size = new System.Drawing.Size(110, 25);
            this.StudentHomeForm_CellNo_label.TabIndex = 5;
            this.StudentHomeForm_CellNo_label.Text = "Cell No : ";
            // 
            // StudentHomeForm_DateOfBirth_label
            // 
            this.StudentHomeForm_DateOfBirth_label.AutoSize = true;
            this.StudentHomeForm_DateOfBirth_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StudentHomeForm_DateOfBirth_label.ForeColor = System.Drawing.Color.Maroon;
            this.StudentHomeForm_DateOfBirth_label.Location = new System.Drawing.Point(133, 318);
            this.StudentHomeForm_DateOfBirth_label.Name = "StudentHomeForm_DateOfBirth_label";
            this.StudentHomeForm_DateOfBirth_label.Size = new System.Drawing.Size(169, 25);
            this.StudentHomeForm_DateOfBirth_label.TabIndex = 6;
            this.StudentHomeForm_DateOfBirth_label.Text = "Date Of Birth : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 48F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(165, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(518, 79);
            this.label1.TabIndex = 7;
            this.label1.Text = "Logged In As Details";
            // 
            // StudentHomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 469);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.StudentHomeForm_DateOfBirth_label);
            this.Controls.Add(this.StudentHomeForm_CellNo_label);
            this.Controls.Add(this.StudentHomeForm_Email_label);
            this.Controls.Add(this.StudentHomeForm_Discipline_label);
            this.Controls.Add(this.StudentHomeForm_Name_label);
            this.Controls.Add(this.StudentHomeForm_ID_label);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "StudentHomeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student";
            this.Load += new System.EventHandler(this.StudentHomeForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem StudentHomeForm_exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registerForThisTermToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resultProcessingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showYourResultToolStripMenuItem;
        private System.Windows.Forms.Label StudentHomeForm_ID_label;
        private System.Windows.Forms.Label StudentHomeForm_Name_label;
        private System.Windows.Forms.Label StudentHomeForm_Discipline_label;
        private System.Windows.Forms.Label StudentHomeForm_Email_label;
        private System.Windows.Forms.Label StudentHomeForm_CellNo_label;
        private System.Windows.Forms.Label StudentHomeForm_DateOfBirth_label;
        private System.Windows.Forms.Label label1;
    }
}