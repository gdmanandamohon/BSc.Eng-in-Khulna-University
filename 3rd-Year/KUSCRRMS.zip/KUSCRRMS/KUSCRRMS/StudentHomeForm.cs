﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KUSCRRMS
{
    public partial class StudentHomeForm : Form
    {
        string ID, Discipline,Student_name;
        public StudentHomeForm(string ID, string Discipline, string Name, string CellNo, string Email, string DateOFBirth)
        {
            this.ID = ID;
            this.Discipline = Discipline;

            this.Student_name = Name;
            InitializeComponent();
            StudentHomeForm_ID_label.Text += " " + ID;
            StudentHomeForm_Discipline_label.Text += " " + Discipline;
            StudentHomeForm_Name_label.Text += " " + Name;
            StudentHomeForm_CellNo_label.Text += " " + CellNo;
            StudentHomeForm_Email_label.Text += " " + Email;
            StudentHomeForm_DateOfBirth_label.Text += " " + DateOFBirth;
            
        }

        private void showYourResultToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintResultForStudent p_result_stu = new PrintResultForStudent(ID, Discipline, Student_name);

            p_result_stu.ShowDialog();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void StudentHomeForm_Load(object sender, EventArgs e)
        {

        }

        private void StudentHomeForm_Name_label_Click(object sender, EventArgs e)
        {

        }

        private void StudentHomeForm_exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
