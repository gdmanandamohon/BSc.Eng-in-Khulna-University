﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KUSCRRMS
{
    public partial class ViewResult : Form
    {
        public ViewResult(string Discipline)
        {
            InitializeComponent();
            ViewResult_Discipline_label.Text = "Dicipline : " + Discipline;
   
        }
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
        private void ViewResult_View_button_Click(object sender, EventArgs e)
        {

            
            LoadResult();
            ViewResult_StudentID_label.Text = "Student ID : " + ViewResult_ID_textBox.Text;
            ViewResult_Year_label.Text = "Year : " + ViewResult_Year_comboBox.Text;
            ViewResult_Term_label.Text = "Term : " + ViewResult_Term_comboBox.Text;

        }

        DataTable table;
        public void LoadResult()
        {
            string ID = ViewResult_ID_textBox.Text;
            string Term = ViewResult_Term_comboBox.Text;
            string Year = ViewResult_Year_comboBox.Text;
            if (ID != null && Term != null && Year != null)
            {
                string query = "select * from TotalResults where ID = '" + ID + "' AND TERM = '" + Term + "' AND YEAR = '" + Year + "'";
                
                SqlCommand cmd = new SqlCommand(query, connection);
                try
                {

                    SqlDataAdapter sda = new SqlDataAdapter();
                    sda.SelectCommand = cmd;
                    table = new DataTable();
                    sda.Fill(table);
                    BindingSource bs = new BindingSource();
                    bs.DataSource = table;
                    ViewResult_dataGridView.DataSource = bs;
                    ViewResult_dataGridView.DataSource = bs;
                    sda.Update(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("please fill up all Items");
                }
            }
            else
                MessageBox.Show("please fill up all Items");

        }

        private void ViewResult_ID_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ViewResult_ID_textBox.Text)
            {
                ViewResult_ID_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ViewResult_ID_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ViewResult_ID_textBox.Text = sb.ToString();
                this.ViewResult_ID_textBox.SelectionStart = this.ViewResult_ID_textBox.Text.Length;
            }
        }

        private void ViewResult_Term_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewResult_Year_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ViewResult_Discipline_label_Click(object sender, EventArgs e)
        {

        }
    }
}
