﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KUSCRRMS
{
    public partial class HomeForm : Form
    {
        String Discipline;
        public HomeForm(string abc)
        {
            InitializeComponent();
            DisciplineNAme_label.Text = abc+" Discipline";
            this.Discipline = abc;
            HomeForm_Time_label.Text += DateTime.Now.ToString();
        }

        private void HomeForm_Load(object sender, EventArgs e)
        {

        }

        private void homeformmenuStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void homeForm_Menustrip_File_toolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void homeForm_Menustrip_New_AddStudent_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewStudent adnewstu = new AddNewStudent();
            adnewstu.Show();
        }

        private void homeForm_Menustrip_File_Exit_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void homeForm_Menustrip_New_AddResult_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            ResultAddition resultadition = new ResultAddition();
            resultadition.Show();
        }

        private void HomeForm_Load_1(object sender, EventArgs e)
        {

        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.ApplicationExitCall) return;

            switch (MessageBox.Show(this, "Exit Result Management?", "KU Course Reg And Result Processing", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
                default:
                    Application.ExitThread();
                    break;
            }
        }

        private void addMajorCoursesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddMajorCourses admajorcourse = new AddMajorCourses();
            admajorcourse.Show();
        }

        private void homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemoveMajorCourses removemajorCourses = new RemoveMajorCourses();
            removemajorCourses.Show();

        }

        private void homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewDiscipline adnewdiscipline = new AddNewDiscipline();
            adnewdiscipline.Show();
        }

        private void homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditCourseForCurrentTem editcoursecurrentterm = new EditCourseForCurrentTem();
            editcoursecurrentterm.Show();
        }

        private void homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewResult viewresult = new ViewResult(Discipline);
            viewresult.Show();
        }

        private void homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintResult presult = new PrintResult();
            presult.Show();
        }

        private void DisciplineNAme_label_Click(object sender, EventArgs e)
        {

        }

        private void HomeForm_Time_label_Click(object sender, EventArgs e)
        {

        }
        

       
       
    }
}
