﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class AddNewStudent : Form
    {
        public AddNewStudent()
        {
            InitializeComponent();
        }

        private static void SaveData(string ID, string Discipline, string Name, string CelNo, string Email, string DateOfBirth)
        {
            

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void AddNewStudent_Load(object sender, EventArgs e)
        {
            AddNewStudent_ID_textBox.MaxLength = 6;
            load_all_discipline();
            AddNewStudent_Name_textBox.MaxLength = 150;

        }

        private void addNewStu_Cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();

        }

        private void addNewStu_Done_button_Click(object sender, EventArgs e)
        {
            
            string ID = AddNewStudent_ID_textBox.Text;
            string Discipline = AddNewStudent_Discipline_comboBox.Text;
            string Name = AddNewStudent_Name_textBox.Text;
            string CellNo = AddNewStudent_cellNo_textBox.Text;
            string Email = AddNewStudent_Email_textBox.Text;
            string DateOfBirth = AddNewStudent_DateOfBirth_dateTimePicker.Text;
            if (ID != null && Discipline != null && Name != null)
            {
                try
                {
                    string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO Studentinformation (ID, Discipline, Name, CellNo, Email, DateOfBirth) VALUES (@ID, @Discipline, @Name, @CellNo, @Email, @DateOfBirth)";
                        command.Parameters.AddWithValue("@ID", ID);
                        command.Parameters.AddWithValue("@Discipline", Discipline);
                        command.Parameters.AddWithValue("@Name", Name);
                        command.Parameters.AddWithValue("@CellNo", CellNo);
                        command.Parameters.AddWithValue("@Email", Email);
                        command.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Sucessfully Added About " + ID + " As " + " Name:" + Name);
                        AddNewStudent_ID_textBox.Text=null;
                        AddNewStudent_Discipline_comboBox.Text=null;
                        AddNewStudent_Name_textBox.Text=null;
                        AddNewStudent_cellNo_textBox.Text=null;
                        AddNewStudent_Email_textBox.Text = null;
                        AddNewStudent_ID_textBox.Focus();


                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Invalid!!!  \n You must Input Add ID Name And Discipline");
                }
            }
            else
            {
                MessageBox.Show("Invalid!!!  \n  You must Input Add ID Name And Discipline");
            }
        }




        private void AddNewStudent_ID_textBox_TextChanged(object sender, EventArgs e)
        {
            
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.AddNewStudent_ID_textBox.Text)
            {
                AddNewStudent_ID_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                AddNewStudent_ID_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.AddNewStudent_ID_textBox.Text = sb.ToString();
                this.AddNewStudent_ID_textBox.SelectionStart = this.AddNewStudent_ID_textBox.Text.Length;
            }
        }
        

        private void AddNewStudent_Discipline_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        public void load_all_discipline()
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select distinct DisciplineName from dbo.AllDiscipline";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["DisciplineName"].ToString();
                AddNewStudent_Discipline_comboBox.Items.Add(username);

            }
            connection.Close();

        }

        private void AddNewStudent_Name_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.AddNewStudent_Name_textBox.Text)
            {
                AddNewStudent_Name_textBox.BackColor = System.Drawing.Color.White;
                if (!char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                AddNewStudent_Name_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Do not Insert Numeric Value in Name Field");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.AddNewStudent_Name_textBox.Text = sb.ToString();
                this.AddNewStudent_Name_textBox.SelectionStart = this.AddNewStudent_Name_textBox.Text.Length;
            }
        }

        private void AddNewStudent_cellNo_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.AddNewStudent_cellNo_textBox.Text)
            {
                AddNewStudent_cellNo_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                AddNewStudent_cellNo_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.AddNewStudent_cellNo_textBox.Text = sb.ToString();
                this.AddNewStudent_cellNo_textBox.SelectionStart = this.AddNewStudent_cellNo_textBox.Text.Length;
            }
        }

        private void AddNewStudent_Email_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddNewStudent_DateOfBirth_dateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
