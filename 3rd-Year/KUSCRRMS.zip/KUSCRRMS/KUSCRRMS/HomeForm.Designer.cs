﻿namespace KUSCRRMS
{
    partial class HomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HomeForm));
            this.homeformmenuStrip = new System.Windows.Forms.MenuStrip();
            this.homeForm_Menustrip_File_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_Edit_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_New_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addMajorCoursesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisciplineNAme_label = new System.Windows.Forms.Label();
            this.HomeForm_Time_label = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.homeformmenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // homeformmenuStrip
            // 
            this.homeformmenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeForm_Menustrip_File_toolStripMenuItem,
            this.homeForm_Menustrip_Edit_toolStripMenuItem,
            this.homeForm_Menustrip_New_toolStripMenuItem,
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem});
            this.homeformmenuStrip.Location = new System.Drawing.Point(0, 0);
            this.homeformmenuStrip.Name = "homeformmenuStrip";
            this.homeformmenuStrip.Size = new System.Drawing.Size(961, 24);
            this.homeformmenuStrip.TabIndex = 0;
            this.homeformmenuStrip.Text = "menuStrip1";
            this.homeformmenuStrip.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.homeformmenuStrip_ItemClicked);
            // 
            // homeForm_Menustrip_File_toolStripMenuItem
            // 
            this.homeForm_Menustrip_File_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem});
            this.homeForm_Menustrip_File_toolStripMenuItem.Name = "homeForm_Menustrip_File_toolStripMenuItem";
            this.homeForm_Menustrip_File_toolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.homeForm_Menustrip_File_toolStripMenuItem.Text = "File";
            this.homeForm_Menustrip_File_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_File_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_File_Exit_toolStripMenuItem
            // 
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem.Name = "homeForm_Menustrip_File_Exit_toolStripMenuItem";
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem.Text = "Exit";
            this.homeForm_Menustrip_File_Exit_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_File_Exit_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_Edit_toolStripMenuItem
            // 
            this.homeForm_Menustrip_Edit_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem,
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem});
            this.homeForm_Menustrip_Edit_toolStripMenuItem.Name = "homeForm_Menustrip_Edit_toolStripMenuItem";
            this.homeForm_Menustrip_Edit_toolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.homeForm_Menustrip_Edit_toolStripMenuItem.Text = "Edit";
            // 
            // homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem
            // 
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem.Name = "homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem";
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem.Text = "Remove A Major Course";
            this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem
            // 
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem.Name = "homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem";
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem.Size = new System.Drawing.Size(228, 22);
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem.Text = "Edit Course For Current Term";
            this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_New_toolStripMenuItem
            // 
            this.homeForm_Menustrip_New_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem,
            this.addMajorCoursesToolStripMenuItem,
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem,
            this.homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem,
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem});
            this.homeForm_Menustrip_New_toolStripMenuItem.Name = "homeForm_Menustrip_New_toolStripMenuItem";
            this.homeForm_Menustrip_New_toolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.homeForm_Menustrip_New_toolStripMenuItem.Text = "New";
            // 
            // homeForm_Menustrip_New_AddResult_toolStripMenuItem
            // 
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem.Name = "homeForm_Menustrip_New_AddResult_toolStripMenuItem";
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem.Text = "Add Result";
            this.homeForm_Menustrip_New_AddResult_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_New_AddResult_toolStripMenuItem_Click);
            // 
            // addMajorCoursesToolStripMenuItem
            // 
            this.addMajorCoursesToolStripMenuItem.Name = "addMajorCoursesToolStripMenuItem";
            this.addMajorCoursesToolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.addMajorCoursesToolStripMenuItem.Text = "Add A Major  Courses ";
            this.addMajorCoursesToolStripMenuItem.Click += new System.EventHandler(this.addMajorCoursesToolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_New_AddStudent_toolStripMenuItem
            // 
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem.Name = "homeForm_Menustrip_New_AddStudent_toolStripMenuItem";
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem.Text = "Add a Student";
            this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_New_AddStudent_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem
            // 
            this.homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem.Name = "homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem";
            this.homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem.Text = "Add Current Term Course";
            // 
            // homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem
            // 
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem.Name = "homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem";
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem.Size = new System.Drawing.Size(210, 22);
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem.Text = "Add A discipline";
            this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_ResultProcess_toolStripMenuItem
            // 
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem,
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem});
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem.Name = "homeForm_Menustrip_ResultProcess_toolStripMenuItem";
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.homeForm_Menustrip_ResultProcess_toolStripMenuItem.Text = "Result Process";
            // 
            // homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem
            // 
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem.Name = "homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem";
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem.Text = "View Result";
            this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem_Click);
            // 
            // homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem
            // 
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem.Name = "homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem";
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem.Text = "Print Result";
            this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem.Click += new System.EventHandler(this.homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem_Click);
            // 
            // DisciplineNAme_label
            // 
            this.DisciplineNAme_label.AutoSize = true;
            this.DisciplineNAme_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DisciplineNAme_label.ForeColor = System.Drawing.Color.Red;
            this.DisciplineNAme_label.Location = new System.Drawing.Point(156, 133);
            this.DisciplineNAme_label.Name = "DisciplineNAme_label";
            this.DisciplineNAme_label.Size = new System.Drawing.Size(177, 39);
            this.DisciplineNAme_label.TabIndex = 1;
            this.DisciplineNAme_label.Text = "Discipline";
            this.DisciplineNAme_label.Click += new System.EventHandler(this.DisciplineNAme_label_Click);
            // 
            // HomeForm_Time_label
            // 
            this.HomeForm_Time_label.AutoSize = true;
            this.HomeForm_Time_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HomeForm_Time_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.HomeForm_Time_label.Location = new System.Drawing.Point(171, 183);
            this.HomeForm_Time_label.Name = "HomeForm_Time_label";
            this.HomeForm_Time_label.Size = new System.Drawing.Size(110, 20);
            this.HomeForm_Time_label.TabIndex = 2;
            this.HomeForm_Time_label.Text = "Local Time : ";
            this.HomeForm_Time_label.Click += new System.EventHandler(this.HomeForm_Time_label_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackgroundImage = global::KUSCRRMS.Properties.Resources.Untitled_0;
            this.pictureBox1.Location = new System.Drawing.Point(817, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(143, 145);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // HomeForm
            // 
            this.ClientSize = new System.Drawing.Size(961, 465);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.HomeForm_Time_label);
            this.Controls.Add(this.DisciplineNAme_label);
            this.Controls.Add(this.homeformmenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.homeformmenuStrip;
            this.Name = "HomeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.HomeForm_Load_1);
            this.homeformmenuStrip.ResumeLayout(false);
            this.homeformmenuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip homeForm_menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem manageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportMarkShToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backupDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreDatabaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem annDisciplineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addCourseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configurationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem addCourseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem withdrawCourseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printRegistrationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studentwiseToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem courseswiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem withdrawCourseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem markEntityToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exploreMarksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printResultToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentwiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem coursewiseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addAStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addSubjectsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem joinMarksToolStripMenuItem;
        private System.Windows.Forms.MenuStrip homeformmenuStrip;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_File_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_File_Exit_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_Edit_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_New_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_New_AddResult_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addMajorCoursesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_New_AddStudent_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_New_AddCurrentCouse_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_Edit_RemoveAMajorCourse_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_New_AddADiscipline_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_Edit_editCourseCurrentTerm_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_ResultProcess_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_ResultProcess_ViewResult_toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeForm_Menustrip_ResultProcess_PrintResult_toolStripMenuItem;
        private System.Windows.Forms.Label DisciplineNAme_label;
        private System.Windows.Forms.Label HomeForm_Time_label;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}