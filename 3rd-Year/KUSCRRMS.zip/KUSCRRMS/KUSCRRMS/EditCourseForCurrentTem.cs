﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KUSCRRMS
{
    public partial class EditCourseForCurrentTem : Form
    {
        public EditCourseForCurrentTem()
        {
            InitializeComponent();
        }

        private void EditCourseForCurrentTem_Load(object sender, EventArgs e)
        {

        }
    }
}
