﻿namespace KUSCRRMS
{
    partial class ViewResult
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewResult));
            this.ViewResult_View_button = new System.Windows.Forms.Button();
            this.ViewResult_Year_comboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ViewResult_Term_comboBox = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ViewResult_ID_textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ViewResult_ViewDetails_label = new System.Windows.Forms.Label();
            this.ViewResult_StudentName_label = new System.Windows.Forms.Label();
            this.ViewResult_StudentID_label = new System.Windows.Forms.Label();
            this.ViewResult_Discipline_label = new System.Windows.Forms.Label();
            this.ViewResult_Year_label = new System.Windows.Forms.Label();
            this.ViewResult_Term_label = new System.Windows.Forms.Label();
            this.ViewResult_dataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.ViewResult_dataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ViewResult_View_button
            // 
            this.ViewResult_View_button.Location = new System.Drawing.Point(604, 31);
            this.ViewResult_View_button.Name = "ViewResult_View_button";
            this.ViewResult_View_button.Size = new System.Drawing.Size(75, 23);
            this.ViewResult_View_button.TabIndex = 13;
            this.ViewResult_View_button.Text = "View";
            this.ViewResult_View_button.UseVisualStyleBackColor = true;
            this.ViewResult_View_button.Click += new System.EventHandler(this.ViewResult_View_button_Click);
            // 
            // ViewResult_Year_comboBox
            // 
            this.ViewResult_Year_comboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.ViewResult_Year_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ViewResult_Year_comboBox.FormattingEnabled = true;
            this.ViewResult_Year_comboBox.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.ViewResult_Year_comboBox.Location = new System.Drawing.Point(441, 32);
            this.ViewResult_Year_comboBox.Name = "ViewResult_Year_comboBox";
            this.ViewResult_Year_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ViewResult_Year_comboBox.TabIndex = 12;
            this.ViewResult_Year_comboBox.SelectedIndexChanged += new System.EventHandler(this.ViewResult_Year_comboBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(380, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Year : ";
            // 
            // ViewResult_Term_comboBox
            // 
            this.ViewResult_Term_comboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "I",
            "II"});
            this.ViewResult_Term_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ViewResult_Term_comboBox.FormattingEnabled = true;
            this.ViewResult_Term_comboBox.Items.AddRange(new object[] {
            "I",
            "II"});
            this.ViewResult_Term_comboBox.Location = new System.Drawing.Point(236, 32);
            this.ViewResult_Term_comboBox.Name = "ViewResult_Term_comboBox";
            this.ViewResult_Term_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ViewResult_Term_comboBox.TabIndex = 10;
            this.ViewResult_Term_comboBox.SelectedIndexChanged += new System.EventHandler(this.ViewResult_Term_comboBox_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(173, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Term : ";
            // 
            // ViewResult_ID_textBox
            // 
            this.ViewResult_ID_textBox.Location = new System.Drawing.Point(55, 32);
            this.ViewResult_ID_textBox.Name = "ViewResult_ID_textBox";
            this.ViewResult_ID_textBox.Size = new System.Drawing.Size(100, 20);
            this.ViewResult_ID_textBox.TabIndex = 8;
            this.ViewResult_ID_textBox.TextChanged += new System.EventHandler(this.ViewResult_ID_textBox_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "ID : ";
            // 
            // ViewResult_ViewDetails_label
            // 
            this.ViewResult_ViewDetails_label.AutoSize = true;
            this.ViewResult_ViewDetails_label.Location = new System.Drawing.Point(278, 76);
            this.ViewResult_ViewDetails_label.Name = "ViewResult_ViewDetails_label";
            this.ViewResult_ViewDetails_label.Size = new System.Drawing.Size(79, 13);
            this.ViewResult_ViewDetails_label.TabIndex = 14;
            this.ViewResult_ViewDetails_label.Text = "Student Details";
            // 
            // ViewResult_StudentName_label
            // 
            this.ViewResult_StudentName_label.AutoSize = true;
            this.ViewResult_StudentName_label.Location = new System.Drawing.Point(339, 111);
            this.ViewResult_StudentName_label.Name = "ViewResult_StudentName_label";
            this.ViewResult_StudentName_label.Size = new System.Drawing.Size(84, 13);
            this.ViewResult_StudentName_label.TabIndex = 15;
            this.ViewResult_StudentName_label.Text = "Student Name : ";
            // 
            // ViewResult_StudentID_label
            // 
            this.ViewResult_StudentID_label.AutoSize = true;
            this.ViewResult_StudentID_label.Location = new System.Drawing.Point(186, 111);
            this.ViewResult_StudentID_label.Name = "ViewResult_StudentID_label";
            this.ViewResult_StudentID_label.Size = new System.Drawing.Size(67, 13);
            this.ViewResult_StudentID_label.TabIndex = 16;
            this.ViewResult_StudentID_label.Text = "Student ID : ";
            // 
            // ViewResult_Discipline_label
            // 
            this.ViewResult_Discipline_label.AutoSize = true;
            this.ViewResult_Discipline_label.Location = new System.Drawing.Point(192, 138);
            this.ViewResult_Discipline_label.Name = "ViewResult_Discipline_label";
            this.ViewResult_Discipline_label.Size = new System.Drawing.Size(61, 13);
            this.ViewResult_Discipline_label.TabIndex = 17;
            this.ViewResult_Discipline_label.Text = "Discipline : ";
            this.ViewResult_Discipline_label.Click += new System.EventHandler(this.ViewResult_Discipline_label_Click);
            // 
            // ViewResult_Year_label
            // 
            this.ViewResult_Year_label.AutoSize = true;
            this.ViewResult_Year_label.Location = new System.Drawing.Point(339, 163);
            this.ViewResult_Year_label.Name = "ViewResult_Year_label";
            this.ViewResult_Year_label.Size = new System.Drawing.Size(38, 13);
            this.ViewResult_Year_label.TabIndex = 20;
            this.ViewResult_Year_label.Text = "Year : ";
            // 
            // ViewResult_Term_label
            // 
            this.ViewResult_Term_label.AutoSize = true;
            this.ViewResult_Term_label.Location = new System.Drawing.Point(213, 163);
            this.ViewResult_Term_label.Name = "ViewResult_Term_label";
            this.ViewResult_Term_label.Size = new System.Drawing.Size(40, 13);
            this.ViewResult_Term_label.TabIndex = 19;
            this.ViewResult_Term_label.Text = "Term : ";
            // 
            // ViewResult_dataGridView
            // 
            this.ViewResult_dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ViewResult_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ViewResult_dataGridView.Location = new System.Drawing.Point(2, 214);
            this.ViewResult_dataGridView.Name = "ViewResult_dataGridView";
            this.ViewResult_dataGridView.Size = new System.Drawing.Size(811, 311);
            this.ViewResult_dataGridView.TabIndex = 21;
            // 
            // ViewResult
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 527);
            this.Controls.Add(this.ViewResult_dataGridView);
            this.Controls.Add(this.ViewResult_Year_label);
            this.Controls.Add(this.ViewResult_Term_label);
            this.Controls.Add(this.ViewResult_Discipline_label);
            this.Controls.Add(this.ViewResult_StudentID_label);
            this.Controls.Add(this.ViewResult_StudentName_label);
            this.Controls.Add(this.ViewResult_ViewDetails_label);
            this.Controls.Add(this.ViewResult_View_button);
            this.Controls.Add(this.ViewResult_Year_comboBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ViewResult_Term_comboBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ViewResult_ID_textBox);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ViewResult";
            this.Text = "View Result";
            ((System.ComponentModel.ISupportInitialize)(this.ViewResult_dataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ViewResult_View_button;
        private System.Windows.Forms.ComboBox ViewResult_Year_comboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox ViewResult_Term_comboBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox ViewResult_ID_textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ViewResult_ViewDetails_label;
        private System.Windows.Forms.Label ViewResult_StudentName_label;
        private System.Windows.Forms.Label ViewResult_StudentID_label;
        private System.Windows.Forms.Label ViewResult_Discipline_label;
        private System.Windows.Forms.Label ViewResult_Year_label;
        private System.Windows.Forms.Label ViewResult_Term_label;
        private System.Windows.Forms.DataGridView ViewResult_dataGridView;
    }
}