﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class AddNewDiscipline : Form
    {
        public AddNewDiscipline()
        {
            InitializeComponent();
            AddNewDiscipline_DisciplineCode_textBox.MaxLength = 2;
        }

        private void AddNewDiscipline_Add_button_Click(object sender, EventArgs e)
        {
            string DisciplineName=AddNewDiscipline_DisciplineName_textBox.Text;
            int DisciplineCode=int.Parse(AddNewDiscipline_DisciplineCode_textBox.Text);
            if (DisciplineName != null && DisciplineCode != null)
            {
                try
                {
                    string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO AllDiscipline (DisciplineName,  DisciplineCode ) VALUES (@DisciplineName, @DisciplineCode)";
                        command.Parameters.AddWithValue("@DisciplineName", DisciplineName);
                        command.Parameters.AddWithValue("@DisciplineCode", DisciplineCode);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Sucessfully Added About " + DisciplineName);
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Invalid!!!  \n You must Input all values atleast 0 or something");
                }
            }
            else
            {
                MessageBox.Show("Invalid!!!  \n You must Input all values atleast 0 or something");
            }
        }

        private void AddNewDiscipline_Load(object sender, EventArgs e)
        {

        }

        private void AddNewDiscipline_DisciplineName_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.AddNewDiscipline_DisciplineName_textBox.Text)
            {
                AddNewDiscipline_DisciplineName_textBox.BackColor = System.Drawing.Color.White;
                if (!char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                AddNewDiscipline_DisciplineName_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Do not Insert Numeric Value in Name Field");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.AddNewDiscipline_DisciplineName_textBox.Text = sb.ToString();
                this.AddNewDiscipline_DisciplineName_textBox.SelectionStart = this.AddNewDiscipline_DisciplineName_textBox.Text.Length;
            }
        }

        private void AddNewDiscipline_DisciplineCode_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.AddNewDiscipline_DisciplineCode_textBox.Text)
            {
                AddNewDiscipline_DisciplineCode_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                AddNewDiscipline_DisciplineCode_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.AddNewDiscipline_DisciplineCode_textBox.Text = sb.ToString();
                this.AddNewDiscipline_DisciplineCode_textBox.SelectionStart = this.AddNewDiscipline_DisciplineCode_textBox.Text.Length;
            }
        }
    }
}
