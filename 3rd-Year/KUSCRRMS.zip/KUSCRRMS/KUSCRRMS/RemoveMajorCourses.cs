﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class RemoveMajorCourses : Form
    {
        public RemoveMajorCourses()
        {
            InitializeComponent();
        }

        private void RemoveMajorCourses_Load(object sender, EventArgs e)
        {
            load_all_discipline();
            load_all_CourseCode();
            load_all_CourseTitle();
            load_all_Credit();

            
        }

        public void load_all_discipline()
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select distinct DisciplineName from dbo.AllDiscipline";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["DisciplineName"].ToString();
                RemoveMajorCourses_Discipline_comboBox.Items.Add(username);

            }
            connection.Close();
            
        }
        public void load_all_CourseCode()
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select distinct CourseCode from dbo.AllMajorCourses";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["CourseCode"].ToString();
                RemoveMajorCourses_CourseCode_comboBox.Items.Add(username);

            }
            connection.Close();

        }
        public void load_all_CourseTitle()
        {

            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select distinct CourseTitle from dbo.AllMajorCourses";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["CourseTitle"].ToString();
                RemoveMajorCourses_CourseTitle_comboBox.Items.Add(username);

            }
            connection.Close();
        }
        public void load_all_Credit()
        {

            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select distinct Credit from dbo.AllMajorCourses";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["Credit"].ToString();
                RemoveMajorCourses_Credit_comboBox.Items.Add(username);

            }
            connection.Close();

        }





        private void RemoveMajorCourses_CourseTitle_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_CourseCode_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Credit_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Term_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Year_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Discipline_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Cancel_button_Click(object sender, EventArgs e)
        {

        }

        private void RemoveMajorCourses_Save_button_Click(object sender, EventArgs e)
        {

            string Discipline = RemoveMajorCourses_Discipline_comboBox.Text;
            string CourseCode = RemoveMajorCourses_CourseCode_comboBox.Text;
            string CourseTitle = RemoveMajorCourses_CourseTitle_comboBox.Text;
            string Credit = RemoveMajorCourses_Credit_comboBox.Text;
            string Term = RemoveMajorCourses_Term_comboBox.Text;
            string Year = RemoveMajorCourses_Year_comboBox.Text;
            if (Discipline != null && CourseCode != null && CourseTitle != null && Credit != null && Term != null && Year != null)
            {
                try
                {
                    SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
                    connection.Open();
                    string query = "DELETE FROM AllMajorCourses WHERE Discipline = " + "'" + Discipline + "'" + " AND CourseCode = " + "'" + CourseCode + "'" + " AND CourseTitle = " + "'" + CourseTitle + "'";
                    SqlCommand cmdo = new SqlCommand(query, connection);
                    cmdo.CommandType = System.Data.CommandType.Text;
                    cmdo.ExecuteNonQuery();
                    cmdo.Clone();
                    connection.Close();
                    MessageBox.Show("Sucessfully Deleted " + CourseCode + " as " + CourseTitle);
                    RemoveMajorCourses_Discipline_comboBox.Text = null;
                    RemoveMajorCourses_CourseCode_comboBox.Text = null;
                    RemoveMajorCourses_CourseTitle_comboBox.Text = null;
                    RemoveMajorCourses_Credit_comboBox.Text = null;
                    RemoveMajorCourses_Term_comboBox.Text = null;
                    RemoveMajorCourses_Year_comboBox.Text = null;
                    
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Invalid!!!  \n You must Input Add ID Name And Discipline");
                }
            }
            else
            {
                MessageBox.Show("Invalid!!!  \n  You must Input Add ID Name And Discipline");
            }
        }
    }
}
