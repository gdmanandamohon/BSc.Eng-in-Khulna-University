﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KUSCRRMS
{
    public partial class LogInForm : Form
    {
        public LogInForm()
        {
            InitializeComponent();
            
        }

        private void LogInForm_Load(object sender, EventArgs e)
        {

        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason == CloseReason.ApplicationExitCall) return;

            switch (MessageBox.Show(this, "Exit Result Management?", "KU Course Reg And Result Processing", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
                default:
                    Application.ExitThread();
                    break;
            }
        }
        private void LogInForm_LogIn_button_Click(object sender, EventArgs e)
        {

            
        }

        private void LogInForm_Username_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoginForm_Password_textBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void LogInForm_admin_button_Click(object sender, EventArgs e)
        {
            AdminLogIn admdskl = new AdminLogIn();
            this.Hide();
            admdskl.ShowDialog();   //& show the main form
                this.Close();
                
            
        }

        private void LogInForm_Student_button_Click(object sender, EventArgs e)
        {
            StudentLogIn admdskl = new StudentLogIn();
            this.Hide();
            admdskl.ShowDialog();   //& show the main form
            this.Close();
            
        }

        
    }
}
