﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;
namespace KUSCRRMS
{
    public partial class PrintResultForStudent : Form
    {
        String ID;
        public PrintResultForStudent(String ID, string Discipline,string Name)
        {
            this.ID = ID;
            InitializeComponent();
            PrintResultStudent_StudentID_label.Text += ID;
            PrintResultStudent_StudentName_label.Text += Name;
           
            PrintResultStudent_Discipline_label.Text += Discipline;


        }
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
        private void PrintResultForStudent_Load(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_View_button_Click(object sender, EventArgs e)
        {
            PrintResultStudent_Term_label.Text = "Term : " +PrintResultStudent_Term_comboBox.Text;
            PrintResultStudent_Year_label.Text = "Year : " +PrintResultStudent_Year_comboBox.Text;
            LoadResult();
            sumCredit();
            calculateGPA();

        }
        public void calculateGPA()
        {
            Double EarnedCredit = 0, Takencredit_multipleGrade = 0, CGPA;


            for (int i = 0; i < PrintResultStudent_dataGridView.Rows.Count; i++)
            {

                string str = Convert.ToString(PrintResultStudent_dataGridView.Rows[i].Cells[2].Value);
                if (str.CompareTo("F") == 0 || str.CompareTo("FF") == 0)
                    continue;
                else if (str.CompareTo("D") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);

                }
                else if (str.CompareTo("C") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.25 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("C+") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.50 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("B-") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.75 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("B") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.0 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("B+") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.25 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("A-") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.5 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("A") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.75 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                else
                {
                    EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 4 * Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }

            }
            CGPA = (Takencredit_multipleGrade / EarnedCredit);

            PrintResultStudent_CGPA_label.Text = "GPA in Current Term : " + CGPA.ToString();
        }
        
        public void sumCredit()
        {
            Double EarnedCredit = 0, Takencredit = 0;

            
                for (int i = 0; i < PrintResultStudent_dataGridView.Rows.Count; i++)
                {
                    
                     string str = Convert.ToString(PrintResultStudent_dataGridView.Rows[i].Cells[2].Value);
                     Takencredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                     if (str.CompareTo("F") == 0 || str.CompareTo("FF") == 0)
                         continue;
                     else

                         EarnedCredit += Convert.ToDouble(PrintResultStudent_dataGridView.Rows[i].Cells[3].Value);
                }
                PrintResultStudent_TotalECR_label.Text = "Total Earned Credit In this Term : " + Convert.ToString(EarnedCredit);
                PrintResultForStudent_TotalCreditTaken_label.Text = "Total Credit Taken In this Term : " + Convert.ToString(Takencredit);
            
        }
     
        DataTable table;
        public void LoadResult()
        {
            
            string Term = PrintResultStudent_Term_comboBox.Text;
            string Year = PrintResultStudent_Year_comboBox.Text;
            if (ID != null && Term != null && Year != null)
            {
                string query = "select CourseCode, CourseTitle, ObtainGrade, Credit from TotalResults where ID = '" + ID + "' AND TERM = '" + Term + "' AND YEAR = '" + Year + "'";

                SqlCommand cmd = new SqlCommand(query, connection);
                try
                {

                    SqlDataAdapter sda = new SqlDataAdapter();
                    sda.SelectCommand = cmd;
                    table = new DataTable();
                    sda.Fill(table);
                    BindingSource bs = new BindingSource();
                    bs.DataSource = table;
                    PrintResultStudent_dataGridView.DataSource = bs;
                    PrintResultStudent_dataGridView.DataSource = bs;
                    sda.Update(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("please fill up all Items");
                }
            }
            else
                MessageBox.Show("please fill up all Items");

        }
        private void PrintResultStudent_StudentID_label_Click(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_StudentName_label_Click(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_Discipline_label_Click(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_Term_label_Click(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_Term_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PrintResultStudent_TotalECR_label_Click(object sender, EventArgs e)
        {

        }

        

        private void PrintResultForStudent_TotalCreditTaken_label_Click(object sender, EventArgs e)
        {

        }


        //   print 
        private void doc_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            Bitmap bmp = new Bitmap(panel1.Width, panel1.Height, panel1.CreateGraphics());
            panel1.DrawToBitmap(bmp, new Rectangle(0, 0, panel1.Width, panel1.Height));

            RectangleF bounds = e.PageSettings.PrintableArea;
            e.Graphics.DrawImage(bmp, bounds.Left, bounds.Top, panel1.Width, panel1.Height);

        }
        
        

        private void PrintResultStudent_Print_button_Click_1(object sender, EventArgs e)
        {
            System.Drawing.Printing.PrintDocument doc = new System.Drawing.Printing.PrintDocument();
             doc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(doc_PrintPage);
            PrintDialog PrintSettings = new PrintDialog();
            PrintSettings.Document = doc;
            PageSettings pgsetting = new PageSettings();

            if (PrintSettings.ShowDialog() == DialogResult.OK)
                doc.Print();

        }
    }
}
