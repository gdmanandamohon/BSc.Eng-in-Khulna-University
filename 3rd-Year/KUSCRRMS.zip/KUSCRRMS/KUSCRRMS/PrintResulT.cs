﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class PrintResult : Form
    {
        public PrintResult()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
        private void PrintResult_ID_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.PrintResult_ID_textBox.Text)
            {
                PrintResult_ID_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                PrintResult_ID_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.PrintResult_ID_textBox.Text = sb.ToString();
                this.PrintResult_ID_textBox.SelectionStart = this.PrintResult_ID_textBox.Text.Length;
            }
        }

        private void PrintResult_View_button_Click(object sender, EventArgs e)
        {
            LoadResult();
            sumCredit();
            calculateGPA();
            PrintResult_StudentID_label.Text = "Student ID : " + PrintResult_ID_textBox.Text;
            PrintResult_Year_label.Text = "Year : " + PrintResult_Year_comboBox.Text;
            PrintResult_Term_label.Text = "Term : " + PrintResult_Term_comboBox.Text;
            
        }
        public void calculateGPA()
        {
            Double EarnedCredit = 0, Takencredit_multipleGrade = 0,CGPA;


            for (int i = 0; i < PrintResult_dataGridView.Rows.Count; i++)
            {

                string str = Convert.ToString(PrintResult_dataGridView.Rows[i].Cells[2].Value);
                if (str.CompareTo("F") == 0 || str.CompareTo("FF") == 0)
                    continue;
                else if(str.CompareTo("D") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);

                }
                else if(str.CompareTo("C") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.25 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if(str.CompareTo("C+") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.50 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if(str.CompareTo("B-") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 2.75 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if(str.CompareTo("B") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.0 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if(str.CompareTo("B+") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.25 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if(str.CompareTo("A-") == 0 )
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.5 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else if (str.CompareTo("A") == 0)
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 3.75 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                else
                {
                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                    Takencredit_multipleGrade += 4 * Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                }
                    
            }
            CGPA = Takencredit_multipleGrade / EarnedCredit;
            PrintResult_CGPA_label.Text = "GPA in Current Term : " + CGPA.ToString();
        }
        public void sumCredit()
        {
            Double EarnedCredit = 0, Takencredit = 0;


            for (int i = 0; i < PrintResult_dataGridView.Rows.Count; i++)
            {

                string str = Convert.ToString(PrintResult_dataGridView.Rows[i].Cells[2].Value);
                Takencredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
                if (str.CompareTo("F") == 0 || str.CompareTo("FF") == 0)
                    continue;
                else

                    EarnedCredit += Convert.ToDouble(PrintResult_dataGridView.Rows[i].Cells[3].Value);
            }
            PrintResult_TotalECR_label.Text = "Total Earned Credit In this Term :  " + Convert.ToString(EarnedCredit);
            PrintResult_TotalCreditTaken_label.Text = "Total Credit Taken In this Term :  " + Convert.ToString(Takencredit);

        }
        DataTable table;
        public void LoadResult()
        {
            string ID = PrintResult_ID_textBox.Text;
            string Term = PrintResult_Term_comboBox.Text;
            string Year = PrintResult_Year_comboBox.Text;
            if (ID != null && Term != null && Year != null)
            {
                string query = "select CourseCode, CourseTitle, ObtainGrade, Credit from TotalResults where ID = '" + ID + "' AND TERM = '" + Term + "' AND YEAR = '" + Year + "'";

                SqlCommand cmd = new SqlCommand(query, connection);
                try
                {

                    SqlDataAdapter sda = new SqlDataAdapter();
                    sda.SelectCommand = cmd;
                    table = new DataTable();
                    sda.Fill(table);
                    BindingSource bs = new BindingSource();
                    bs.DataSource = table;
                    PrintResult_dataGridView.DataSource = bs;
                    PrintResult_dataGridView.DataSource = bs;
                    sda.Update(table);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("please fill up all Items");
                }
            }
            else
                MessageBox.Show("please fill up all Items");

        }
        public void getCredit()
        {
            string ID = PrintResult_ID_textBox.Text;
            string Term = PrintResult_Term_comboBox.Text;
            string Year = PrintResult_Year_comboBox.Text;
            if (ID != null && Term != null && Year != null)
            {
                string query = "select sum(Credit) from TotalResults where ID = '" + ID + "' AND TERM = '" + Term + "' AND YEAR = '" + Year + "' AND ObtainGrade <> 'F'";

                SqlCommand cmd = new SqlCommand(query, connection);
                try
                {

                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("please fill up all Items");
                }
            }
            else
                MessageBox.Show("please fill up all Items");

        }

        private void PrintResult_Load(object sender, EventArgs e)
        {

        }

        private void PrintResult_Print_button_Click(object sender, EventArgs e)
        {

        }
    }
}
