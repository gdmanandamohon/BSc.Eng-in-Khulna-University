﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace KUSCRRMS
{
    public partial class AddMajorCourses : Form
    {
        public AddMajorCourses()
        {
            InitializeComponent();
        }

        private void AddMajorCourses_Load(object sender, EventArgs e)
        {
            load_all_discipline();
        }

        public void load_all_discipline()
        {
            SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
            connection.Open();
            string query = "select DisciplineName from dbo.AllDiscipline";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                string username = rdr["DisciplineName"].ToString();
                AddMajorCourses_Discipline_comboBox.Items.Add(username);

            }
            connection.Close();

        }

        private void AddMajorCourses_Discipline_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddMajorCourses_Save_button_Click(object sender, EventArgs e)
        {
            string Discipline = AddMajorCourses_Discipline_comboBox.Text;
            string CourseCode = AddMajorCourses_CourseCode_textBox.Text;
            string CourseTitle = AddMajorCourses_CourseTitle_textBox.Text;
            string Credit = AddMajorCourses_Credit_comboBox.Text;
            string Term = AddMajorCourses_Term_comboBox.Text;
            string Year = AddMajorCourses_Year_comboBox.Text;
            if (Discipline != null && CourseCode != null && CourseTitle != null && Credit != null && Term != null && Year != null)
            {
                try
                {
                    string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO AllMajorCourses (Discipline, CourseCode, CourseTitle, Credit, Term, Year) VALUES (@Discipline, @CourseCode, @CourseTitle, @Credit, @Term, @Year)";
                        command.Parameters.AddWithValue("@Discipline", Discipline);
                        command.Parameters.AddWithValue("@CourseCode", CourseCode);
                        command.Parameters.AddWithValue("@CourseTitle", CourseTitle);
                        command.Parameters.AddWithValue("@Credit", Credit);
                        command.Parameters.AddWithValue("@Term", Term);
                        command.Parameters.AddWithValue("@Year", Year);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Sucessfully Added About " + CourseCode + " As " + " Name:" + CourseTitle);
                        AddMajorCourses_CourseCode_textBox.Text = null;
                        AddMajorCourses_CourseTitle_textBox.Text = null;
                        AddMajorCourses_Credit_comboBox.Text = null;
                        AddMajorCourses_Term_comboBox.Text = null;
                        AddMajorCourses_Year_comboBox.Text = null;

                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Invalid!!!  \n You must Input Add ID Name And Discipline");
                }
            }
            else
            {
                MessageBox.Show("Invalid!!!  \n  You must Input Add ID Name And Discipline");
            }

        }

        private void AddMajorCourses_Cancel_button_Click(object sender, EventArgs e)
        {

        }
    }
}
