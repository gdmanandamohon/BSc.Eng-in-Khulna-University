﻿namespace KUSCRRMS
{
    partial class AddNewStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewStudent));
            this.addNewStu_Done_button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.addNewStu_Cancel_button = new System.Windows.Forms.Button();
            this.AddNewStudent_ID_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AddNewStudent_Email_textBox = new System.Windows.Forms.TextBox();
            this.AddNewStudent_cellNo_textBox = new System.Windows.Forms.TextBox();
            this.AddNewStudent_Name_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.AddNewStudent_Discipline_comboBox = new System.Windows.Forms.ComboBox();
            this.AddNewStudent_DateOfBirth_dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // addNewStu_Done_button
            // 
            this.addNewStu_Done_button.Location = new System.Drawing.Point(237, 268);
            this.addNewStu_Done_button.Name = "addNewStu_Done_button";
            this.addNewStu_Done_button.Size = new System.Drawing.Size(84, 33);
            this.addNewStu_Done_button.TabIndex = 0;
            this.addNewStu_Done_button.Text = "Done";
            this.addNewStu_Done_button.UseVisualStyleBackColor = true;
            this.addNewStu_Done_button.Click += new System.EventHandler(this.addNewStu_Done_button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(127, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "add New student here";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // addNewStu_Cancel_button
            // 
            this.addNewStu_Cancel_button.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.addNewStu_Cancel_button.Location = new System.Drawing.Point(91, 268);
            this.addNewStu_Cancel_button.Name = "addNewStu_Cancel_button";
            this.addNewStu_Cancel_button.Size = new System.Drawing.Size(84, 33);
            this.addNewStu_Cancel_button.TabIndex = 2;
            this.addNewStu_Cancel_button.Text = "Cancel";
            this.addNewStu_Cancel_button.UseVisualStyleBackColor = true;
            this.addNewStu_Cancel_button.Click += new System.EventHandler(this.addNewStu_Cancel_button_Click);
            // 
            // AddNewStudent_ID_textBox
            // 
            this.AddNewStudent_ID_textBox.Location = new System.Drawing.Point(91, 69);
            this.AddNewStudent_ID_textBox.Name = "AddNewStudent_ID_textBox";
            this.AddNewStudent_ID_textBox.Size = new System.Drawing.Size(230, 20);
            this.AddNewStudent_ID_textBox.TabIndex = 3;
            this.AddNewStudent_ID_textBox.TextChanged += new System.EventHandler(this.AddNewStudent_ID_textBox_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(54, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "ID :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // AddNewStudent_Email_textBox
            // 
            this.AddNewStudent_Email_textBox.Location = new System.Drawing.Point(91, 188);
            this.AddNewStudent_Email_textBox.Name = "AddNewStudent_Email_textBox";
            this.AddNewStudent_Email_textBox.Size = new System.Drawing.Size(230, 20);
            this.AddNewStudent_Email_textBox.TabIndex = 5;
            this.AddNewStudent_Email_textBox.TextChanged += new System.EventHandler(this.AddNewStudent_Email_textBox_TextChanged);
            // 
            // AddNewStudent_cellNo_textBox
            // 
            this.AddNewStudent_cellNo_textBox.Location = new System.Drawing.Point(91, 157);
            this.AddNewStudent_cellNo_textBox.Name = "AddNewStudent_cellNo_textBox";
            this.AddNewStudent_cellNo_textBox.Size = new System.Drawing.Size(230, 20);
            this.AddNewStudent_cellNo_textBox.TabIndex = 6;
            this.AddNewStudent_cellNo_textBox.TextChanged += new System.EventHandler(this.AddNewStudent_cellNo_textBox_TextChanged);
            // 
            // AddNewStudent_Name_textBox
            // 
            this.AddNewStudent_Name_textBox.Location = new System.Drawing.Point(91, 125);
            this.AddNewStudent_Name_textBox.Name = "AddNewStudent_Name_textBox";
            this.AddNewStudent_Name_textBox.Size = new System.Drawing.Size(230, 20);
            this.AddNewStudent_Name_textBox.TabIndex = 8;
            this.AddNewStudent_Name_textBox.TextChanged += new System.EventHandler(this.AddNewStudent_Name_textBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 128);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Discipline :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 213);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Date of Birth :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(37, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Cell No :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(46, 188);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Email :";
            // 
            // AddNewStudent_Discipline_comboBox
            // 
            this.AddNewStudent_Discipline_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddNewStudent_Discipline_comboBox.FormattingEnabled = true;
            this.AddNewStudent_Discipline_comboBox.Location = new System.Drawing.Point(91, 95);
            this.AddNewStudent_Discipline_comboBox.Name = "AddNewStudent_Discipline_comboBox";
            this.AddNewStudent_Discipline_comboBox.Size = new System.Drawing.Size(230, 21);
            this.AddNewStudent_Discipline_comboBox.TabIndex = 15;
            this.AddNewStudent_Discipline_comboBox.SelectedIndexChanged += new System.EventHandler(this.AddNewStudent_Discipline_comboBox_SelectedIndexChanged);
            // 
            // AddNewStudent_DateOfBirth_dateTimePicker
            // 
            this.AddNewStudent_DateOfBirth_dateTimePicker.Location = new System.Drawing.Point(91, 214);
            this.AddNewStudent_DateOfBirth_dateTimePicker.Name = "AddNewStudent_DateOfBirth_dateTimePicker";
            this.AddNewStudent_DateOfBirth_dateTimePicker.Size = new System.Drawing.Size(230, 20);
            this.AddNewStudent_DateOfBirth_dateTimePicker.TabIndex = 16;
            this.AddNewStudent_DateOfBirth_dateTimePicker.ValueChanged += new System.EventHandler(this.AddNewStudent_DateOfBirth_dateTimePicker_ValueChanged);
            // 
            // AddNewStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(396, 328);
            this.Controls.Add(this.AddNewStudent_DateOfBirth_dateTimePicker);
            this.Controls.Add(this.AddNewStudent_Discipline_comboBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AddNewStudent_Name_textBox);
            this.Controls.Add(this.AddNewStudent_cellNo_textBox);
            this.Controls.Add(this.AddNewStudent_Email_textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AddNewStudent_ID_textBox);
            this.Controls.Add(this.addNewStu_Cancel_button);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addNewStu_Done_button);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddNewStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add New Student";
            this.Load += new System.EventHandler(this.AddNewStudent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button addNewStu_Done_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button addNewStu_Cancel_button;
        private System.Windows.Forms.TextBox AddNewStudent_ID_textBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AddNewStudent_Email_textBox;
        private System.Windows.Forms.TextBox AddNewStudent_cellNo_textBox;
        private System.Windows.Forms.TextBox AddNewStudent_Name_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox AddNewStudent_Discipline_comboBox;
        private System.Windows.Forms.DateTimePicker AddNewStudent_DateOfBirth_dateTimePicker;
    }
}