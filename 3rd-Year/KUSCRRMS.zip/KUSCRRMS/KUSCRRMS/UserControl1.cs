﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CustomTextBox
{
    public partial class CustomTextBox : UserControl
    {
        TextBox textBox1 = new TextBox();
        public CustomTextBox()
        {
            InitializeComponent();
            textBox1.Multiline = true;
            textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            textBox1.Font = this.Font;
            textBox1.BackColor = this.BackColor;
            this.Controls.Add(textBox1);
        }
        public override string  Text
        {
            get { return textBox1.Text; }
            set { textBox1.Text = value; }
        }
        public Color BorderColor = Color.Blue;
        private void CustomTextBox_SizeChanged(object sender, EventArgs e)
        {
            textBox1.Size = new Size(this.Width - 3, this.Height - 2);
            textBox1.Location = new Point(2, 1);
            textBox1.Font = this.Font;
            textBox1.BackColor = this.BackColor;
        }
        public enum BorderSides{Left,Right,Top,Bottom,All}        
        public BorderSides SetBorderSide= BorderSides.All;
        int BorderSize =1;
        private void CustomTextBox_Paint(object sender, PaintEventArgs e)
        {
            Rectangle txtRect = this.ClientRectangle;
            //txtRect.Width = txtRect.Width - 3;
            //txtRect.X += 2;
            switch (SetBorderSide)
            {
                case BorderSides.All:
                    ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid);
                    break;
                case BorderSides.Left:
                    ControlPaint.DrawBorder(e.Graphics, txtRect, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid);
                    break;
                case BorderSides.Top:
                    ControlPaint.DrawBorder(e.Graphics, txtRect, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid);
                    break;
                case BorderSides.Right:
                    ControlPaint.DrawBorder(e.Graphics, txtRect, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid);
                    break;
                case BorderSides.Bottom:
                    ControlPaint.DrawBorder(e.Graphics, txtRect, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, 0, ButtonBorderStyle.Solid, BorderColor, BorderSize, ButtonBorderStyle.Solid);
                    break;
                default:
                    break;
            }
            textBox1.BackColor = this.BackColor;
        }

   

    }
}
