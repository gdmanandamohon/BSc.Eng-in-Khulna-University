﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace KUSCRRMS
{
    public partial class AdminLogIn : Form
    {
        public AdminLogIn()
        {
            InitializeComponent();
        }
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
        private void LAdminLogIn_LogIn_button_Click(object sender, EventArgs e)
        {
            
           
            string AdminID = AdminLogIn_Username_textBox.Text, AdminPassword = AdminLogIn_Password_textBox.Text;
            string query = "SELECT AdminID, AdminPassword FROM Admin where AdminID = @AdminID AND AdminPassword = @AdminPassword";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@AdminID", AdminID);
            cmd.Parameters.AddWithValue("@AdminPassword", AdminPassword);
            connection.Open();
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            
            if (dt.Tables[0].Rows.Count > 0)
            {
                MessageBox.Show("Login Sucessfull.Click OK to continue", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                connection.Close();
                callNextForm();
            }
            else
            {
                
                MessageBox.Show("Wrong Username/Password! \n Please try again!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                AdminLogIn_Username_textBox.Text = ""; 
                AdminLogIn_Password_textBox.Text = "";
            }
            connection.Close();
        }
        public void callNextForm()
        {
            string abc;
            string AdminID = AdminLogIn_Username_textBox.Text;
            string query = "SELECT Discipline FROM Admin where AdminID = '"+AdminID+"'";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr;
            connection.Open();
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                abc = rdr["Discipline"].ToString();
                MessageBox.Show("logged in as Admin "+abc+" Discipline.");
                HomeForm homeform = new HomeForm(abc);
                this.Hide();
                homeform.ShowDialog();
                this.Close();

            }
            
        
        }

        private void AdminLogIn_Load(object sender, EventArgs e)
        {
            AdminLogIn_LogIn_button.Hide();
        }

        private void AdminLogIn_Password_textBox_TextChanged(object sender, EventArgs e)
        {
            /*AdminLogIn_Password_textBox.PasswordChar = '*';*/
            AdminLogIn_Password_textBox.MaxLength = 10;
            AdminLogIn_LogIn_button.Show();
            if (AdminLogIn_Password_textBox.Text == null)
                AdminLogIn_LogIn_button.Hide();
        }

        private void AdminLogIn_Back_button_Click(object sender, EventArgs e)
        {
            LogInForm lfninfrm = new LogInForm();
            this.Hide();
            lfninfrm.ShowDialog();
            
            this.Close();
        }
    }
}
