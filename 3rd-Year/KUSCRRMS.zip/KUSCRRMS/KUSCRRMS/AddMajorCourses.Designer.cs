﻿namespace KUSCRRMS
{
    partial class AddMajorCourses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddMajorCourses));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.AddMajorCourses_Discipline_comboBox = new System.Windows.Forms.ComboBox();
            this.AddMajorCourses_CourseCode_textBox = new System.Windows.Forms.TextBox();
            this.AddMajorCourses_CourseTitle_textBox = new System.Windows.Forms.TextBox();
            this.AddMajorCourses_Credit_comboBox = new System.Windows.Forms.ComboBox();
            this.AddMajorCourses_Term_comboBox = new System.Windows.Forms.ComboBox();
            this.AddMajorCourses_Year_comboBox = new System.Windows.Forms.ComboBox();
            this.AddMajorCourses_Cancel_button = new System.Windows.Forms.Button();
            this.AddMajorCourses_Save_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(28, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Discipline : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 36);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Course Code :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(203, 40);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Course Title : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(45, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Credit :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(235, 73);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Term :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(424, 69);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Year :";
            // 
            // AddMajorCourses_Discipline_comboBox
            // 
            this.AddMajorCourses_Discipline_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddMajorCourses_Discipline_comboBox.FormattingEnabled = true;
            this.AddMajorCourses_Discipline_comboBox.Location = new System.Drawing.Point(93, 9);
            this.AddMajorCourses_Discipline_comboBox.Name = "AddMajorCourses_Discipline_comboBox";
            this.AddMajorCourses_Discipline_comboBox.Size = new System.Drawing.Size(496, 21);
            this.AddMajorCourses_Discipline_comboBox.TabIndex = 6;
            this.AddMajorCourses_Discipline_comboBox.SelectedIndexChanged += new System.EventHandler(this.AddMajorCourses_Discipline_comboBox_SelectedIndexChanged);
            // 
            // AddMajorCourses_CourseCode_textBox
            // 
            this.AddMajorCourses_CourseCode_textBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.AddMajorCourses_CourseCode_textBox.Location = new System.Drawing.Point(93, 37);
            this.AddMajorCourses_CourseCode_textBox.Name = "AddMajorCourses_CourseCode_textBox";
            this.AddMajorCourses_CourseCode_textBox.Size = new System.Drawing.Size(100, 20);
            this.AddMajorCourses_CourseCode_textBox.TabIndex = 7;
            // 
            // AddMajorCourses_CourseTitle_textBox
            // 
            this.AddMajorCourses_CourseTitle_textBox.Location = new System.Drawing.Point(281, 37);
            this.AddMajorCourses_CourseTitle_textBox.Name = "AddMajorCourses_CourseTitle_textBox";
            this.AddMajorCourses_CourseTitle_textBox.Size = new System.Drawing.Size(308, 20);
            this.AddMajorCourses_CourseTitle_textBox.TabIndex = 8;
            // 
            // AddMajorCourses_Credit_comboBox
            // 
            this.AddMajorCourses_Credit_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddMajorCourses_Credit_comboBox.FormattingEnabled = true;
            this.AddMajorCourses_Credit_comboBox.Location = new System.Drawing.Point(93, 65);
            this.AddMajorCourses_Credit_comboBox.Name = "AddMajorCourses_Credit_comboBox";
            this.AddMajorCourses_Credit_comboBox.Size = new System.Drawing.Size(121, 21);
            this.AddMajorCourses_Credit_comboBox.TabIndex = 9;
            // 
            // AddMajorCourses_Term_comboBox
            // 
            this.AddMajorCourses_Term_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddMajorCourses_Term_comboBox.FormattingEnabled = true;
            this.AddMajorCourses_Term_comboBox.Items.AddRange(new object[] {
            "I",
            "II"});
            this.AddMajorCourses_Term_comboBox.Location = new System.Drawing.Point(281, 65);
            this.AddMajorCourses_Term_comboBox.Name = "AddMajorCourses_Term_comboBox";
            this.AddMajorCourses_Term_comboBox.Size = new System.Drawing.Size(121, 21);
            this.AddMajorCourses_Term_comboBox.TabIndex = 10;
            // 
            // AddMajorCourses_Year_comboBox
            // 
            this.AddMajorCourses_Year_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddMajorCourses_Year_comboBox.FormattingEnabled = true;
            this.AddMajorCourses_Year_comboBox.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.AddMajorCourses_Year_comboBox.Location = new System.Drawing.Point(468, 65);
            this.AddMajorCourses_Year_comboBox.Name = "AddMajorCourses_Year_comboBox";
            this.AddMajorCourses_Year_comboBox.Size = new System.Drawing.Size(121, 21);
            this.AddMajorCourses_Year_comboBox.TabIndex = 11;
            // 
            // AddMajorCourses_Cancel_button
            // 
            this.AddMajorCourses_Cancel_button.Location = new System.Drawing.Point(384, 113);
            this.AddMajorCourses_Cancel_button.Name = "AddMajorCourses_Cancel_button";
            this.AddMajorCourses_Cancel_button.Size = new System.Drawing.Size(75, 23);
            this.AddMajorCourses_Cancel_button.TabIndex = 12;
            this.AddMajorCourses_Cancel_button.Text = "Cancel";
            this.AddMajorCourses_Cancel_button.UseVisualStyleBackColor = true;
            this.AddMajorCourses_Cancel_button.Click += new System.EventHandler(this.AddMajorCourses_Cancel_button_Click);
            // 
            // AddMajorCourses_Save_button
            // 
            this.AddMajorCourses_Save_button.Location = new System.Drawing.Point(489, 113);
            this.AddMajorCourses_Save_button.Name = "AddMajorCourses_Save_button";
            this.AddMajorCourses_Save_button.Size = new System.Drawing.Size(75, 23);
            this.AddMajorCourses_Save_button.TabIndex = 13;
            this.AddMajorCourses_Save_button.Text = "Update";
            this.AddMajorCourses_Save_button.UseVisualStyleBackColor = true;
            this.AddMajorCourses_Save_button.Click += new System.EventHandler(this.AddMajorCourses_Save_button_Click);
            // 
            // AddMajorCourses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 148);
            this.Controls.Add(this.AddMajorCourses_Save_button);
            this.Controls.Add(this.AddMajorCourses_Cancel_button);
            this.Controls.Add(this.AddMajorCourses_Year_comboBox);
            this.Controls.Add(this.AddMajorCourses_Term_comboBox);
            this.Controls.Add(this.AddMajorCourses_Credit_comboBox);
            this.Controls.Add(this.AddMajorCourses_CourseTitle_textBox);
            this.Controls.Add(this.AddMajorCourses_CourseCode_textBox);
            this.Controls.Add(this.AddMajorCourses_Discipline_comboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddMajorCourses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add A Major Course of Your discipline";
            this.Load += new System.EventHandler(this.AddMajorCourses_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox AddMajorCourses_Discipline_comboBox;
        private System.Windows.Forms.TextBox AddMajorCourses_CourseCode_textBox;
        private System.Windows.Forms.TextBox AddMajorCourses_CourseTitle_textBox;
        private System.Windows.Forms.ComboBox AddMajorCourses_Credit_comboBox;
        private System.Windows.Forms.ComboBox AddMajorCourses_Term_comboBox;
        private System.Windows.Forms.ComboBox AddMajorCourses_Year_comboBox;
        private System.Windows.Forms.Button AddMajorCourses_Cancel_button;
        private System.Windows.Forms.Button AddMajorCourses_Save_button;
    }
}