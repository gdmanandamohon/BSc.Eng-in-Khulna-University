﻿namespace KUSCRRMS
{
    partial class AdminLogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminLogIn));
            this.AdminLogIn_LogIn_button = new System.Windows.Forms.Button();
            this.AdminLogIn_Password_textBox = new System.Windows.Forms.TextBox();
            this.AdminLogIn_Username_textBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AdminLogIn_Back_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // AdminLogIn_LogIn_button
            // 
            this.AdminLogIn_LogIn_button.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminLogIn_LogIn_button.Location = new System.Drawing.Point(306, 111);
            this.AdminLogIn_LogIn_button.Name = "AdminLogIn_LogIn_button";
            this.AdminLogIn_LogIn_button.Size = new System.Drawing.Size(65, 35);
            this.AdminLogIn_LogIn_button.TabIndex = 13;
            this.AdminLogIn_LogIn_button.Text = "Log IN";
            this.AdminLogIn_LogIn_button.UseVisualStyleBackColor = true;
            this.AdminLogIn_LogIn_button.Click += new System.EventHandler(this.LAdminLogIn_LogIn_button_Click);
            // 
            // AdminLogIn_Password_textBox
            // 
            this.AdminLogIn_Password_textBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AdminLogIn_Password_textBox.Location = new System.Drawing.Point(207, 84);
            this.AdminLogIn_Password_textBox.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.AdminLogIn_Password_textBox.Name = "AdminLogIn_Password_textBox";
            this.AdminLogIn_Password_textBox.Size = new System.Drawing.Size(164, 20);
            this.AdminLogIn_Password_textBox.TabIndex = 12;
            this.AdminLogIn_Password_textBox.UseSystemPasswordChar = true;
            this.AdminLogIn_Password_textBox.TextChanged += new System.EventHandler(this.AdminLogIn_Password_textBox_TextChanged);
            // 
            // AdminLogIn_Username_textBox
            // 
            this.AdminLogIn_Username_textBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.AdminLogIn_Username_textBox.Location = new System.Drawing.Point(207, 56);
            this.AdminLogIn_Username_textBox.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.AdminLogIn_Username_textBox.Name = "AdminLogIn_Username_textBox";
            this.AdminLogIn_Username_textBox.Size = new System.Drawing.Size(164, 20);
            this.AdminLogIn_Username_textBox.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(125, 84);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Password";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(123, 56);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Username";
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(31, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(328, 27);
            this.label1.TabIndex = 8;
            this.label1.Text = "Khulna University Result Management Toolkit";
            // 
            // AdminLogIn_Back_button
            // 
            this.AdminLogIn_Back_button.Font = new System.Drawing.Font("Corbel", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminLogIn_Back_button.Location = new System.Drawing.Point(207, 111);
            this.AdminLogIn_Back_button.Name = "AdminLogIn_Back_button";
            this.AdminLogIn_Back_button.Size = new System.Drawing.Size(72, 35);
            this.AdminLogIn_Back_button.TabIndex = 14;
            this.AdminLogIn_Back_button.Text = "Back";
            this.AdminLogIn_Back_button.UseVisualStyleBackColor = true;
            this.AdminLogIn_Back_button.Click += new System.EventHandler(this.AdminLogIn_Back_button_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::KUSCRRMS.Properties.Resources.kulogobest;
            this.pictureBox1.Location = new System.Drawing.Point(8, 56);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(101, 131);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // AdminLogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(385, 201);
            this.Controls.Add(this.AdminLogIn_Back_button);
            this.Controls.Add(this.AdminLogIn_LogIn_button);
            this.Controls.Add(this.AdminLogIn_Password_textBox);
            this.Controls.Add(this.AdminLogIn_Username_textBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminLogIn";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin Log In";
            this.Load += new System.EventHandler(this.AdminLogIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AdminLogIn_LogIn_button;
        private System.Windows.Forms.TextBox AdminLogIn_Password_textBox;
        private System.Windows.Forms.TextBox AdminLogIn_Username_textBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button AdminLogIn_Back_button;
    }
}