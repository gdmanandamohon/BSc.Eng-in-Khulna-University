﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class StudentLogIn : Form
    {
        public StudentLogIn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LogInForm lfninfrm = new LogInForm();
            this.Hide();
            lfninfrm.ShowDialog();   
            this.Close();
        }
        SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30");
        private void StudentLogIn_LogIn_button_Click(object sender, EventArgs e)
        {
            
           
            string ID = StudentLogIn_ID_textBox.Text, DateOfBirth = StudentLogIn_DateOfBirth_dateTimePicker.Text;

            string query = "SELECT ID, DateOfBirth FROM Studentinformation where ID = @ID AND DateOfBirth = @DateOfBirth";
            SqlCommand cmd = new SqlCommand(query, connection);
            cmd.Parameters.AddWithValue("@ID", ID);
            cmd.Parameters.AddWithValue("@DateOfBirth", DateOfBirth);
            connection.Open();
            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            DataSet dt = new DataSet();
            ad.Fill(dt);
            if (dt.Tables[0].Rows.Count > 0)
            {
                MessageBox.Show("Login Sucessfull.Click OK to continue", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information);
                connection.Close();
                callNextForm();
            }
            else
            {
                MessageBox.Show("Wrong Username/Password! \n Please try again!", "Login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                StudentLogIn_ID_textBox.Text = "";
                StudentLogIn_DateOfBirth_dateTimePicker.BackColor = Color.Pink;
            }
            connection.Close();
        }
        public void callNextForm()
        {
            string Discipline,Name,CellNo,Email,DateOFBirth;
            string ID = StudentLogIn_ID_textBox.Text;
            string query = "SELECT * FROM Studentinformation where ID = '" + ID+"'";
            SqlCommand cmd = new SqlCommand(query, connection);
            SqlDataReader rdr;
            connection.Open();
            rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Discipline = rdr["Discipline"].ToString();
                
                Name = rdr["Name"].ToString();
                CellNo = rdr["CellNo"].ToString();
                Email = rdr["Email"].ToString();
                DateOFBirth = rdr["DateOfBirth"].ToString();
                
                StudentHomeForm sStudentHomeForm = new StudentHomeForm(ID, Discipline, Name, CellNo, Email, DateOFBirth);
                this.Hide();
                sStudentHomeForm.ShowDialog(); 
                this.Close();

            }
            connection.Close();
        
        }

        private void StudentLogIn_ID_textBox_TextChanged(object sender, EventArgs e)
        {

            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.StudentLogIn_ID_textBox.Text)
            {
                StudentLogIn_ID_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                StudentLogIn_ID_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.StudentLogIn_ID_textBox.Text = sb.ToString();
                this.StudentLogIn_ID_textBox.SelectionStart = this.StudentLogIn_ID_textBox.Text.Length;
            }
        }

        private void StudentLogIn_Load(object sender, EventArgs e)
        {

        }
    }
}
