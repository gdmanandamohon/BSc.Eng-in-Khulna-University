﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KUSCRRMS
{
    public partial class ResultAddition : Form
    {
        public ResultAddition()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void ResultAddition_ID_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_ID_textBox.Text)
            {
                ResultAddition_ID_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_ID_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_ID_textBox.Text = sb.ToString();
                this.ResultAddition_ID_textBox.SelectionStart = this.ResultAddition_ID_textBox.Text.Length;
            }
        }

        private void ResultAddition_CourseCode_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_CourseTitle_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_SECA_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_SECA_textBox.Text)
            {
                ResultAddition_SECA_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_SECA_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_SECA_textBox.Text = sb.ToString();
                this.ResultAddition_SECA_textBox.SelectionStart = this.ResultAddition_SECA_textBox.Text.Length;
            }
        }

        private void ResultAddition_SECB_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_SECB_textBox.Text)
            {
                ResultAddition_SECB_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_SECB_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_SECB_textBox.Text = sb.ToString();
                this.ResultAddition_SECB_textBox.SelectionStart = this.ResultAddition_SECB_textBox.Text.Length;
            }
        }

        private void ResultAddition_CT1_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_CT1_textBox.Text)
            {
                ResultAddition_CT1_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_CT1_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_CT1_textBox.Text = sb.ToString();
                this.ResultAddition_CT1_textBox.SelectionStart = this.ResultAddition_CT1_textBox.Text.Length;
            }
        }

        private void ResultAddition_CT2_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_CT2_textBox.Text)
            {
                ResultAddition_CT2_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_CT2_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_CT2_textBox.Text = sb.ToString();
                this.ResultAddition_CT2_textBox.SelectionStart = this.ResultAddition_CT2_textBox.Text.Length;
            }
        }

        private void ResultAddition_CT3_textBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_Attendance_textBox_TextChanged(object sender, EventArgs e)
        {
            bool enteredLetter = false;
            Queue<char> text = new Queue<char>();
            foreach (var ch in this.ResultAddition_Attendance_textBox.Text)
            {
                ResultAddition_Attendance_textBox.BackColor = System.Drawing.Color.White;
                if (char.IsDigit(ch))
                {
                    text.Enqueue(ch);
                }
                else
                {
                    enteredLetter = true;
                }
            }

            if (enteredLetter)
            {
                ResultAddition_Attendance_textBox.BackColor = System.Drawing.Color.Red;
                StringBuilder sb = new StringBuilder();
                MessageBox.Show("Only Numeric value only");
                while (text.Count > 0)
                {
                    sb.Append(text.Dequeue());
                }

                this.ResultAddition_Attendance_textBox.Text = sb.ToString();
                this.ResultAddition_Attendance_textBox.SelectionStart = this.ResultAddition_Attendance_textBox.Text.Length;
            }
        }

        private void ResultAddition_TotalMarks_textBox_TextChanged(object sender, EventArgs e)
        {
            int SECA, SECB, CT1, CT2, Attendance, TotalMarks;
            SECA = int.Parse(ResultAddition_SECA_textBox.Text);
            SECB = int.Parse(ResultAddition_SECB_textBox.Text);
            CT1 = int.Parse(ResultAddition_CT1_textBox.Text);
            CT2 = int.Parse(ResultAddition_CT2_textBox.Text);
            Attendance = int.Parse(ResultAddition_Attendance_textBox.Text);
            TotalMarks = SECA + SECB + CT1 + CT2+Attendance;
            ResultAddition_TotalMarks_textBox.Text = TotalMarks.ToString();
            //MessageBox.Show(ResultAddition_TotalMarks_textBox.Text);

        }

        private void ResultAddition_GradePoint_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_CrediT_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_Term_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_Year_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ResultAddition_Save_button_Click(object sender, EventArgs e)
        {
            
            string ID, CourseCode,CourseTitle, Term, Year,ObtainGrade;
            int SECA, SECB, CT1, CT2, Attendance, TotalMarks;
            ID = ResultAddition_ID_textBox.Text;
            CourseCode = ResultAddition_CourseCode_textBox.Text;
            CourseTitle = ResultAddition_CourseTitle_textBox.Text;
            Term = ResultAddition_Term_comboBox.Text;
            Year = ResultAddition_Year_comboBox.Text;
            SECA = int.Parse(ResultAddition_SECA_textBox.Text);
            SECB = int.Parse(ResultAddition_SECB_textBox.Text);
            CT1 = int.Parse(ResultAddition_CT1_textBox.Text);
            CT2 = int.Parse(ResultAddition_CT2_textBox.Text);
            Attendance = int.Parse(ResultAddition_Attendance_textBox.Text);
            TotalMarks = int.Parse(ResultAddition_TotalMarks_textBox.Text);
            ObtainGrade = ResultAddition_ObtainGrade_comboBox.Text;
            float Credit = float.Parse(ResultAddition_CrediT_comboBox.Text);
            Term = ResultAddition_Term_comboBox.Text;
            Year = ResultAddition_Year_comboBox.Text;

            //MessageBox.Show(Credit.ToString());

            if (ID != null && CourseCode != null && CourseTitle != null && ID != null && ObtainGrade != null && Term != null && Year != null )
            {
                try
                {
                    string connectionString = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=F:\3rd Year\1 st Term\CSE 3102 lab\Project\KUSCRRMS\DataBase\KUSIFRMS.mdf;Integrated Security=True;Connect Timeout=30";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO TotalResults (ID, CourseCode, CourseTitle, SECA, SECB, CT1, CT2, Attendance,TotalMarks, ObtainGrade, Credit,Term, Year ) VALUES (@ID, @CourseCode, @CourseTitle, @SECA, @SECB, @CT1, @CT2, @Attendance,@TotalMarks, @ObtainGrade, @Credit,@Term, @Year)";
                        command.Parameters.AddWithValue("@ID", ID);
                        command.Parameters.AddWithValue("@CourseCode",CourseCode );
                        command.Parameters.AddWithValue("@CourseTitle",CourseTitle );
                        command.Parameters.AddWithValue("@SECA", SECA);
                        command.Parameters.AddWithValue("@SECB", SECB);
                        command.Parameters.AddWithValue("@CT1",CT1 );
                        command.Parameters.AddWithValue("@CT2",CT2 );
                        command.Parameters.AddWithValue("@Attendance",Attendance );
                        command.Parameters.AddWithValue("@TotalMarks",TotalMarks );
                        command.Parameters.AddWithValue("@ObtainGrade",ObtainGrade );
                        command.Parameters.AddWithValue("@Credit", Credit);
                        command.Parameters.AddWithValue("@Term", Term);
                        command.Parameters.AddWithValue("@Year", Year);


                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                        MessageBox.Show("Sucessfully Added About " + ID );
                    }
                }
                catch (SqlException ex)
                {
                    Console.WriteLine(ex.Message);
                    MessageBox.Show("Invalid!!!  \n You must Input all values atleast 0 or something");
                }
            }
            else
            {
                MessageBox.Show("Invalid!!!  \n You must Input all values atleast 0 or something");
            }

        }

        private void ResultAddition_Cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Hide();
        }
    }
}
