﻿namespace KUSCRRMS
{
    partial class ResultAddition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResultAddition));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.ResultAddition_ID_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_CourseCode_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_CourseTitle_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_SECA_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_SECB_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_CT1_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_CT2_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_Attendance_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_TotalMarks_textBox = new System.Windows.Forms.TextBox();
            this.ResultAddition_ObtainGrade_comboBox = new System.Windows.Forms.ComboBox();
            this.ResultAddition_CrediT_comboBox = new System.Windows.Forms.ComboBox();
            this.ResultAddition_Term_comboBox = new System.Windows.Forms.ComboBox();
            this.ResultAddition_Year_comboBox = new System.Windows.Forms.ComboBox();
            this.ResultAddition_Cancel_button = new System.Windows.Forms.Button();
            this.ResultAddition_Save_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(185, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Marks Entry";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(215, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Course Code : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Course Title : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(37, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "SEC-A :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(245, 95);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "SEC-B : ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 122);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "CT-1 :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(256, 121);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "CT-2 :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 151);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Attendance :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(223, 155);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(69, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Total Marks :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 177);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Obtain Grade :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(226, 180);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Credit Hour :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(43, 204);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "Term :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(256, 209);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(35, 13);
            this.label15.TabIndex = 14;
            this.label15.Text = "Year :";
            // 
            // ResultAddition_ID_textBox
            // 
            this.ResultAddition_ID_textBox.Location = new System.Drawing.Point(87, 43);
            this.ResultAddition_ID_textBox.Name = "ResultAddition_ID_textBox";
            this.ResultAddition_ID_textBox.Size = new System.Drawing.Size(122, 20);
            this.ResultAddition_ID_textBox.TabIndex = 15;
            this.ResultAddition_ID_textBox.TextChanged += new System.EventHandler(this.ResultAddition_ID_textBox_TextChanged);
            // 
            // ResultAddition_CourseCode_textBox
            // 
            this.ResultAddition_CourseCode_textBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.ResultAddition_CourseCode_textBox.Location = new System.Drawing.Point(297, 43);
            this.ResultAddition_CourseCode_textBox.Name = "ResultAddition_CourseCode_textBox";
            this.ResultAddition_CourseCode_textBox.Size = new System.Drawing.Size(122, 20);
            this.ResultAddition_CourseCode_textBox.TabIndex = 16;
            this.ResultAddition_CourseCode_textBox.TextChanged += new System.EventHandler(this.ResultAddition_CourseCode_textBox_TextChanged);
            // 
            // ResultAddition_CourseTitle_textBox
            // 
            this.ResultAddition_CourseTitle_textBox.Location = new System.Drawing.Point(87, 69);
            this.ResultAddition_CourseTitle_textBox.Name = "ResultAddition_CourseTitle_textBox";
            this.ResultAddition_CourseTitle_textBox.Size = new System.Drawing.Size(332, 20);
            this.ResultAddition_CourseTitle_textBox.TabIndex = 17;
            this.ResultAddition_CourseTitle_textBox.TextChanged += new System.EventHandler(this.ResultAddition_CourseTitle_textBox_TextChanged);
            // 
            // ResultAddition_SECA_textBox
            // 
            this.ResultAddition_SECA_textBox.Location = new System.Drawing.Point(87, 95);
            this.ResultAddition_SECA_textBox.Name = "ResultAddition_SECA_textBox";
            this.ResultAddition_SECA_textBox.Size = new System.Drawing.Size(122, 20);
            this.ResultAddition_SECA_textBox.TabIndex = 18;
            this.ResultAddition_SECA_textBox.TextChanged += new System.EventHandler(this.ResultAddition_SECA_textBox_TextChanged);
            // 
            // ResultAddition_SECB_textBox
            // 
            this.ResultAddition_SECB_textBox.Location = new System.Drawing.Point(298, 95);
            this.ResultAddition_SECB_textBox.Name = "ResultAddition_SECB_textBox";
            this.ResultAddition_SECB_textBox.Size = new System.Drawing.Size(121, 20);
            this.ResultAddition_SECB_textBox.TabIndex = 19;
            this.ResultAddition_SECB_textBox.TextChanged += new System.EventHandler(this.ResultAddition_SECB_textBox_TextChanged);
            // 
            // ResultAddition_CT1_textBox
            // 
            this.ResultAddition_CT1_textBox.Location = new System.Drawing.Point(87, 122);
            this.ResultAddition_CT1_textBox.Name = "ResultAddition_CT1_textBox";
            this.ResultAddition_CT1_textBox.Size = new System.Drawing.Size(121, 20);
            this.ResultAddition_CT1_textBox.TabIndex = 20;
            this.ResultAddition_CT1_textBox.TextChanged += new System.EventHandler(this.ResultAddition_CT1_textBox_TextChanged);
            // 
            // ResultAddition_CT2_textBox
            // 
            this.ResultAddition_CT2_textBox.Location = new System.Drawing.Point(298, 121);
            this.ResultAddition_CT2_textBox.Name = "ResultAddition_CT2_textBox";
            this.ResultAddition_CT2_textBox.Size = new System.Drawing.Size(121, 20);
            this.ResultAddition_CT2_textBox.TabIndex = 21;
            this.ResultAddition_CT2_textBox.TextChanged += new System.EventHandler(this.ResultAddition_CT2_textBox_TextChanged);
            // 
            // ResultAddition_Attendance_textBox
            // 
            this.ResultAddition_Attendance_textBox.Location = new System.Drawing.Point(87, 148);
            this.ResultAddition_Attendance_textBox.Name = "ResultAddition_Attendance_textBox";
            this.ResultAddition_Attendance_textBox.Size = new System.Drawing.Size(121, 20);
            this.ResultAddition_Attendance_textBox.TabIndex = 23;
            this.ResultAddition_Attendance_textBox.TextChanged += new System.EventHandler(this.ResultAddition_Attendance_textBox_TextChanged);
            // 
            // ResultAddition_TotalMarks_textBox
            // 
            this.ResultAddition_TotalMarks_textBox.Location = new System.Drawing.Point(298, 151);
            this.ResultAddition_TotalMarks_textBox.Name = "ResultAddition_TotalMarks_textBox";
            this.ResultAddition_TotalMarks_textBox.Size = new System.Drawing.Size(121, 20);
            this.ResultAddition_TotalMarks_textBox.TabIndex = 24;
            this.ResultAddition_TotalMarks_textBox.TextChanged += new System.EventHandler(this.ResultAddition_TotalMarks_textBox_TextChanged);
            // 
            // ResultAddition_ObtainGrade_comboBox
            // 
            this.ResultAddition_ObtainGrade_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResultAddition_ObtainGrade_comboBox.FormattingEnabled = true;
            this.ResultAddition_ObtainGrade_comboBox.Items.AddRange(new object[] {
            "A+",
            "A",
            "A-",
            "B+",
            "B",
            "B-",
            "C+",
            "C",
            "D",
            "F",
            "FF"});
            this.ResultAddition_ObtainGrade_comboBox.Location = new System.Drawing.Point(87, 174);
            this.ResultAddition_ObtainGrade_comboBox.Name = "ResultAddition_ObtainGrade_comboBox";
            this.ResultAddition_ObtainGrade_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ResultAddition_ObtainGrade_comboBox.TabIndex = 25;
            this.ResultAddition_ObtainGrade_comboBox.SelectedIndexChanged += new System.EventHandler(this.ResultAddition_GradePoint_comboBox_SelectedIndexChanged);
            // 
            // ResultAddition_CrediT_comboBox
            // 
            this.ResultAddition_CrediT_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResultAddition_CrediT_comboBox.FormattingEnabled = true;
            this.ResultAddition_CrediT_comboBox.Items.AddRange(new object[] {
            "5",
            "4.5",
            "4",
            "3.5",
            "3",
            "2.5",
            "2",
            "1.50",
            "1",
            "0.75",
            "0.5"});
            this.ResultAddition_CrediT_comboBox.Location = new System.Drawing.Point(297, 177);
            this.ResultAddition_CrediT_comboBox.Name = "ResultAddition_CrediT_comboBox";
            this.ResultAddition_CrediT_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ResultAddition_CrediT_comboBox.TabIndex = 26;
            this.ResultAddition_CrediT_comboBox.SelectedIndexChanged += new System.EventHandler(this.ResultAddition_CrediT_comboBox_SelectedIndexChanged);
            // 
            // ResultAddition_Term_comboBox
            // 
            this.ResultAddition_Term_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResultAddition_Term_comboBox.FormattingEnabled = true;
            this.ResultAddition_Term_comboBox.Items.AddRange(new object[] {
            "I",
            "II"});
            this.ResultAddition_Term_comboBox.Location = new System.Drawing.Point(87, 201);
            this.ResultAddition_Term_comboBox.Name = "ResultAddition_Term_comboBox";
            this.ResultAddition_Term_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ResultAddition_Term_comboBox.TabIndex = 27;
            this.ResultAddition_Term_comboBox.SelectedIndexChanged += new System.EventHandler(this.ResultAddition_Term_comboBox_SelectedIndexChanged);
            // 
            // ResultAddition_Year_comboBox
            // 
            this.ResultAddition_Year_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ResultAddition_Year_comboBox.FormattingEnabled = true;
            this.ResultAddition_Year_comboBox.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.ResultAddition_Year_comboBox.Location = new System.Drawing.Point(297, 204);
            this.ResultAddition_Year_comboBox.Name = "ResultAddition_Year_comboBox";
            this.ResultAddition_Year_comboBox.Size = new System.Drawing.Size(121, 21);
            this.ResultAddition_Year_comboBox.TabIndex = 28;
            this.ResultAddition_Year_comboBox.SelectedIndexChanged += new System.EventHandler(this.ResultAddition_Year_comboBox_SelectedIndexChanged);
            // 
            // ResultAddition_Cancel_button
            // 
            this.ResultAddition_Cancel_button.Location = new System.Drawing.Point(134, 254);
            this.ResultAddition_Cancel_button.Name = "ResultAddition_Cancel_button";
            this.ResultAddition_Cancel_button.Size = new System.Drawing.Size(75, 23);
            this.ResultAddition_Cancel_button.TabIndex = 29;
            this.ResultAddition_Cancel_button.Text = "Cancel";
            this.ResultAddition_Cancel_button.UseVisualStyleBackColor = true;
            this.ResultAddition_Cancel_button.Click += new System.EventHandler(this.ResultAddition_Cancel_button_Click);
            // 
            // ResultAddition_Save_button
            // 
            this.ResultAddition_Save_button.Location = new System.Drawing.Point(297, 254);
            this.ResultAddition_Save_button.Name = "ResultAddition_Save_button";
            this.ResultAddition_Save_button.Size = new System.Drawing.Size(75, 23);
            this.ResultAddition_Save_button.TabIndex = 30;
            this.ResultAddition_Save_button.Text = "Save";
            this.ResultAddition_Save_button.UseVisualStyleBackColor = true;
            this.ResultAddition_Save_button.Click += new System.EventHandler(this.ResultAddition_Save_button_Click);
            // 
            // ResultAddition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(450, 307);
            this.Controls.Add(this.ResultAddition_Save_button);
            this.Controls.Add(this.ResultAddition_Cancel_button);
            this.Controls.Add(this.ResultAddition_Year_comboBox);
            this.Controls.Add(this.ResultAddition_Term_comboBox);
            this.Controls.Add(this.ResultAddition_CrediT_comboBox);
            this.Controls.Add(this.ResultAddition_ObtainGrade_comboBox);
            this.Controls.Add(this.ResultAddition_TotalMarks_textBox);
            this.Controls.Add(this.ResultAddition_Attendance_textBox);
            this.Controls.Add(this.ResultAddition_CT2_textBox);
            this.Controls.Add(this.ResultAddition_CT1_textBox);
            this.Controls.Add(this.ResultAddition_SECB_textBox);
            this.Controls.Add(this.ResultAddition_SECA_textBox);
            this.Controls.Add(this.ResultAddition_CourseTitle_textBox);
            this.Controls.Add(this.ResultAddition_CourseCode_textBox);
            this.Controls.Add(this.ResultAddition_ID_textBox);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResultAddition";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Result Addition";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox ResultAddition_ID_textBox;
        private System.Windows.Forms.TextBox ResultAddition_CourseCode_textBox;
        private System.Windows.Forms.TextBox ResultAddition_CourseTitle_textBox;
        private System.Windows.Forms.TextBox ResultAddition_SECA_textBox;
        private System.Windows.Forms.TextBox ResultAddition_SECB_textBox;
        private System.Windows.Forms.TextBox ResultAddition_CT1_textBox;
        private System.Windows.Forms.TextBox ResultAddition_CT2_textBox;
        private System.Windows.Forms.TextBox ResultAddition_Attendance_textBox;
        private System.Windows.Forms.TextBox ResultAddition_TotalMarks_textBox;
        private System.Windows.Forms.ComboBox ResultAddition_ObtainGrade_comboBox;
        private System.Windows.Forms.ComboBox ResultAddition_CrediT_comboBox;
        private System.Windows.Forms.ComboBox ResultAddition_Term_comboBox;
        private System.Windows.Forms.ComboBox ResultAddition_Year_comboBox;
        private System.Windows.Forms.Button ResultAddition_Cancel_button;
        private System.Windows.Forms.Button ResultAddition_Save_button;
    }
}