﻿namespace KUSCRRMS
{
    partial class PrintResultForStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrintResultForStudent));
            this.label2 = new System.Windows.Forms.Label();
            this.PrintResultStudent_Term_comboBox = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.PrintResultStudent_Year_comboBox = new System.Windows.Forms.ComboBox();
            this.PrintResultStudent_View_button = new System.Windows.Forms.Button();
            this.PrintResultStudent_ViewDetails_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_StudentName_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_StudentID_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_Discipline_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_Term_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_Year_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_dataGridView = new System.Windows.Forms.DataGridView();
            this.PrintResultStudent_TotalECR_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_CGPA_label = new System.Windows.Forms.Label();
            this.PrintResultStudent_Print_button = new System.Windows.Forms.Button();
            this.PrintResultForStudent_TotalCreditTaken_label = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.PrintResultStudent_dataGridView)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Term : ";
            // 
            // PrintResultStudent_Term_comboBox
            // 
            this.PrintResultStudent_Term_comboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "I",
            "II"});
            this.PrintResultStudent_Term_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PrintResultStudent_Term_comboBox.FormattingEnabled = true;
            this.PrintResultStudent_Term_comboBox.Items.AddRange(new object[] {
            "I",
            "II"});
            this.PrintResultStudent_Term_comboBox.Location = new System.Drawing.Point(84, 12);
            this.PrintResultStudent_Term_comboBox.Name = "PrintResultStudent_Term_comboBox";
            this.PrintResultStudent_Term_comboBox.Size = new System.Drawing.Size(53, 21);
            this.PrintResultStudent_Term_comboBox.TabIndex = 34;
            this.PrintResultStudent_Term_comboBox.SelectedIndexChanged += new System.EventHandler(this.PrintResultStudent_Term_comboBox_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(148, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 35;
            this.label3.Text = "Year : ";
            // 
            // PrintResultStudent_Year_comboBox
            // 
            this.PrintResultStudent_Year_comboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.PrintResultStudent_Year_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PrintResultStudent_Year_comboBox.FormattingEnabled = true;
            this.PrintResultStudent_Year_comboBox.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.PrintResultStudent_Year_comboBox.Location = new System.Drawing.Point(192, 12);
            this.PrintResultStudent_Year_comboBox.Name = "PrintResultStudent_Year_comboBox";
            this.PrintResultStudent_Year_comboBox.Size = new System.Drawing.Size(76, 21);
            this.PrintResultStudent_Year_comboBox.TabIndex = 36;
            // 
            // PrintResultStudent_View_button
            // 
            this.PrintResultStudent_View_button.Location = new System.Drawing.Point(313, 12);
            this.PrintResultStudent_View_button.Name = "PrintResultStudent_View_button";
            this.PrintResultStudent_View_button.Size = new System.Drawing.Size(74, 27);
            this.PrintResultStudent_View_button.TabIndex = 37;
            this.PrintResultStudent_View_button.Text = "View";
            this.PrintResultStudent_View_button.UseVisualStyleBackColor = true;
            this.PrintResultStudent_View_button.Click += new System.EventHandler(this.PrintResultStudent_View_button_Click);
            // 
            // PrintResultStudent_ViewDetails_label
            // 
            this.PrintResultStudent_ViewDetails_label.AutoSize = true;
            this.PrintResultStudent_ViewDetails_label.Location = new System.Drawing.Point(177, 11);
            this.PrintResultStudent_ViewDetails_label.Name = "PrintResultStudent_ViewDetails_label";
            this.PrintResultStudent_ViewDetails_label.Size = new System.Drawing.Size(79, 13);
            this.PrintResultStudent_ViewDetails_label.TabIndex = 38;
            this.PrintResultStudent_ViewDetails_label.Text = "Student Details";
            // 
            // PrintResultStudent_StudentName_label
            // 
            this.PrintResultStudent_StudentName_label.AutoSize = true;
            this.PrintResultStudent_StudentName_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_StudentName_label.Location = new System.Drawing.Point(247, 39);
            this.PrintResultStudent_StudentName_label.Name = "PrintResultStudent_StudentName_label";
            this.PrintResultStudent_StudentName_label.Size = new System.Drawing.Size(117, 16);
            this.PrintResultStudent_StudentName_label.TabIndex = 39;
            this.PrintResultStudent_StudentName_label.Text = "Student Name : ";
            this.PrintResultStudent_StudentName_label.Click += new System.EventHandler(this.PrintResultStudent_StudentName_label_Click);
            // 
            // PrintResultStudent_StudentID_label
            // 
            this.PrintResultStudent_StudentID_label.AutoSize = true;
            this.PrintResultStudent_StudentID_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_StudentID_label.Location = new System.Drawing.Point(69, 36);
            this.PrintResultStudent_StudentID_label.Name = "PrintResultStudent_StudentID_label";
            this.PrintResultStudent_StudentID_label.Size = new System.Drawing.Size(91, 16);
            this.PrintResultStudent_StudentID_label.TabIndex = 40;
            this.PrintResultStudent_StudentID_label.Text = "Student ID : ";
            this.PrintResultStudent_StudentID_label.Click += new System.EventHandler(this.PrintResultStudent_StudentID_label_Click);
            // 
            // PrintResultStudent_Discipline_label
            // 
            this.PrintResultStudent_Discipline_label.AutoSize = true;
            this.PrintResultStudent_Discipline_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_Discipline_label.Location = new System.Drawing.Point(75, 61);
            this.PrintResultStudent_Discipline_label.Name = "PrintResultStudent_Discipline_label";
            this.PrintResultStudent_Discipline_label.Size = new System.Drawing.Size(89, 16);
            this.PrintResultStudent_Discipline_label.TabIndex = 41;
            this.PrintResultStudent_Discipline_label.Text = "Discipline : ";
            this.PrintResultStudent_Discipline_label.Click += new System.EventHandler(this.PrintResultStudent_Discipline_label_Click);
            // 
            // PrintResultStudent_Term_label
            // 
            this.PrintResultStudent_Term_label.AutoSize = true;
            this.PrintResultStudent_Term_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_Term_label.Location = new System.Drawing.Point(96, 84);
            this.PrintResultStudent_Term_label.Name = "PrintResultStudent_Term_label";
            this.PrintResultStudent_Term_label.Size = new System.Drawing.Size(56, 16);
            this.PrintResultStudent_Term_label.TabIndex = 42;
            this.PrintResultStudent_Term_label.Text = "Term : ";
            this.PrintResultStudent_Term_label.Click += new System.EventHandler(this.PrintResultStudent_Term_label_Click);
            // 
            // PrintResultStudent_Year_label
            // 
            this.PrintResultStudent_Year_label.AutoSize = true;
            this.PrintResultStudent_Year_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_Year_label.Location = new System.Drawing.Point(252, 84);
            this.PrintResultStudent_Year_label.Name = "PrintResultStudent_Year_label";
            this.PrintResultStudent_Year_label.Size = new System.Drawing.Size(53, 16);
            this.PrintResultStudent_Year_label.TabIndex = 43;
            this.PrintResultStudent_Year_label.Text = "Year : ";
            // 
            // PrintResultStudent_dataGridView
            // 
            this.PrintResultStudent_dataGridView.AllowUserToDeleteRows = false;
            this.PrintResultStudent_dataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.PrintResultStudent_dataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.PrintResultStudent_dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PrintResultStudent_dataGridView.Location = new System.Drawing.Point(19, 116);
            this.PrintResultStudent_dataGridView.Name = "PrintResultStudent_dataGridView";
            this.PrintResultStudent_dataGridView.ReadOnly = true;
            this.PrintResultStudent_dataGridView.Size = new System.Drawing.Size(473, 260);
            this.PrintResultStudent_dataGridView.TabIndex = 44;
            // 
            // PrintResultStudent_TotalECR_label
            // 
            this.PrintResultStudent_TotalECR_label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.PrintResultStudent_TotalECR_label.AutoSize = true;
            this.PrintResultStudent_TotalECR_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_TotalECR_label.Location = new System.Drawing.Point(16, 412);
            this.PrintResultStudent_TotalECR_label.Name = "PrintResultStudent_TotalECR_label";
            this.PrintResultStudent_TotalECR_label.Size = new System.Drawing.Size(223, 15);
            this.PrintResultStudent_TotalECR_label.TabIndex = 45;
            this.PrintResultStudent_TotalECR_label.Text = "Total Earned Credit In this Term : ";
            this.PrintResultStudent_TotalECR_label.Click += new System.EventHandler(this.PrintResultStudent_TotalECR_label_Click);
            // 
            // PrintResultStudent_CGPA_label
            // 
            this.PrintResultStudent_CGPA_label.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.PrintResultStudent_CGPA_label.AutoSize = true;
            this.PrintResultStudent_CGPA_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultStudent_CGPA_label.Location = new System.Drawing.Point(18, 429);
            this.PrintResultStudent_CGPA_label.Name = "PrintResultStudent_CGPA_label";
            this.PrintResultStudent_CGPA_label.Size = new System.Drawing.Size(146, 15);
            this.PrintResultStudent_CGPA_label.TabIndex = 46;
            this.PrintResultStudent_CGPA_label.Text = "GPA in Current Term :";
            // 
            // PrintResultStudent_Print_button
            // 
            this.PrintResultStudent_Print_button.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.PrintResultStudent_Print_button.Location = new System.Drawing.Point(207, 525);
            this.PrintResultStudent_Print_button.Name = "PrintResultStudent_Print_button";
            this.PrintResultStudent_Print_button.Size = new System.Drawing.Size(75, 48);
            this.PrintResultStudent_Print_button.TabIndex = 47;
            this.PrintResultStudent_Print_button.Text = "Print a Copy";
            this.PrintResultStudent_Print_button.UseVisualStyleBackColor = true;
            this.PrintResultStudent_Print_button.Click += new System.EventHandler(this.PrintResultStudent_Print_button_Click_1);
            // 
            // PrintResultForStudent_TotalCreditTaken_label
            // 
            this.PrintResultForStudent_TotalCreditTaken_label.AutoSize = true;
            this.PrintResultForStudent_TotalCreditTaken_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PrintResultForStudent_TotalCreditTaken_label.Location = new System.Drawing.Point(16, 396);
            this.PrintResultForStudent_TotalCreditTaken_label.Name = "PrintResultForStudent_TotalCreditTaken_label";
            this.PrintResultForStudent_TotalCreditTaken_label.Size = new System.Drawing.Size(216, 15);
            this.PrintResultForStudent_TotalCreditTaken_label.TabIndex = 48;
            this.PrintResultForStudent_TotalCreditTaken_label.Text = "Total Credit Taken In this Term : ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.PrintResultStudent_TotalECR_label);
            this.panel1.Controls.Add(this.PrintResultStudent_dataGridView);
            this.panel1.Controls.Add(this.PrintResultStudent_Year_label);
            this.panel1.Controls.Add(this.PrintResultForStudent_TotalCreditTaken_label);
            this.panel1.Controls.Add(this.PrintResultStudent_Term_label);
            this.panel1.Controls.Add(this.PrintResultStudent_CGPA_label);
            this.panel1.Controls.Add(this.PrintResultStudent_Discipline_label);
            this.panel1.Controls.Add(this.PrintResultStudent_StudentID_label);
            this.panel1.Controls.Add(this.PrintResultStudent_StudentName_label);
            this.panel1.Controls.Add(this.PrintResultStudent_ViewDetails_label);
            this.panel1.Location = new System.Drawing.Point(12, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(509, 461);
            this.panel1.TabIndex = 49;
            // 
            // PrintResultForStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 597);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.PrintResultStudent_Print_button);
            this.Controls.Add(this.PrintResultStudent_Year_comboBox);
            this.Controls.Add(this.PrintResultStudent_View_button);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.PrintResultStudent_Term_comboBox);
            this.Controls.Add(this.label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PrintResultForStudent";
            this.Text = "PrintResultForStudent";
            this.Load += new System.EventHandler(this.PrintResultForStudent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PrintResultStudent_dataGridView)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox PrintResultStudent_Term_comboBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox PrintResultStudent_Year_comboBox;
        private System.Windows.Forms.Button PrintResultStudent_View_button;
        private System.Windows.Forms.Label PrintResultStudent_ViewDetails_label;
        private System.Windows.Forms.Label PrintResultStudent_StudentName_label;
        private System.Windows.Forms.Label PrintResultStudent_StudentID_label;
        private System.Windows.Forms.Label PrintResultStudent_Discipline_label;
        private System.Windows.Forms.Label PrintResultStudent_Term_label;
        private System.Windows.Forms.Label PrintResultStudent_Year_label;
        private System.Windows.Forms.DataGridView PrintResultStudent_dataGridView;
        private System.Windows.Forms.Label PrintResultStudent_TotalECR_label;
        private System.Windows.Forms.Label PrintResultStudent_CGPA_label;
        private System.Windows.Forms.Button PrintResultStudent_Print_button;
        private System.Windows.Forms.Label PrintResultForStudent_TotalCreditTaken_label;
        private System.Windows.Forms.Panel panel1;



    }
}