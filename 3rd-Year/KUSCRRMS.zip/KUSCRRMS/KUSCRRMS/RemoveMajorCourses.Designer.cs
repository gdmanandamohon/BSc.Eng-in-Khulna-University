﻿namespace KUSCRRMS
{
    partial class RemoveMajorCourses
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RemoveMajorCourses));
            this.RemoveMajorCourses_Save_button = new System.Windows.Forms.Button();
            this.RemoveMajorCourses_Cancel_button = new System.Windows.Forms.Button();
            this.RemoveMajorCourses_Year_comboBox = new System.Windows.Forms.ComboBox();
            this.RemoveMajorCourses_Term_comboBox = new System.Windows.Forms.ComboBox();
            this.RemoveMajorCourses_Discipline_comboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.RemoveMajorCourses_CourseCode_comboBox = new System.Windows.Forms.ComboBox();
            this.RemoveMajorCourses_CourseTitle_comboBox = new System.Windows.Forms.ComboBox();
            this.RemoveMajorCourses_Credit_comboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // RemoveMajorCourses_Save_button
            // 
            this.RemoveMajorCourses_Save_button.Location = new System.Drawing.Point(478, 115);
            this.RemoveMajorCourses_Save_button.Name = "RemoveMajorCourses_Save_button";
            this.RemoveMajorCourses_Save_button.Size = new System.Drawing.Size(75, 23);
            this.RemoveMajorCourses_Save_button.TabIndex = 27;
            this.RemoveMajorCourses_Save_button.Text = "Remove";
            this.RemoveMajorCourses_Save_button.UseVisualStyleBackColor = true;
            this.RemoveMajorCourses_Save_button.Click += new System.EventHandler(this.RemoveMajorCourses_Save_button_Click);
            // 
            // RemoveMajorCourses_Cancel_button
            // 
            this.RemoveMajorCourses_Cancel_button.Location = new System.Drawing.Point(373, 115);
            this.RemoveMajorCourses_Cancel_button.Name = "RemoveMajorCourses_Cancel_button";
            this.RemoveMajorCourses_Cancel_button.Size = new System.Drawing.Size(75, 23);
            this.RemoveMajorCourses_Cancel_button.TabIndex = 26;
            this.RemoveMajorCourses_Cancel_button.Text = "Cancel";
            this.RemoveMajorCourses_Cancel_button.UseVisualStyleBackColor = true;
            this.RemoveMajorCourses_Cancel_button.Click += new System.EventHandler(this.RemoveMajorCourses_Cancel_button_Click);
            // 
            // RemoveMajorCourses_Year_comboBox
            // 
            this.RemoveMajorCourses_Year_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_Year_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_Year_comboBox.Items.AddRange(new object[] {
            "1st",
            "2nd",
            "3rd",
            "4th",
            "5th"});
            this.RemoveMajorCourses_Year_comboBox.Location = new System.Drawing.Point(457, 67);
            this.RemoveMajorCourses_Year_comboBox.Name = "RemoveMajorCourses_Year_comboBox";
            this.RemoveMajorCourses_Year_comboBox.Size = new System.Drawing.Size(121, 21);
            this.RemoveMajorCourses_Year_comboBox.TabIndex = 25;
            this.RemoveMajorCourses_Year_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_Year_comboBox_SelectedIndexChanged);
            // 
            // RemoveMajorCourses_Term_comboBox
            // 
            this.RemoveMajorCourses_Term_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_Term_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_Term_comboBox.Items.AddRange(new object[] {
            "I",
            "II"});
            this.RemoveMajorCourses_Term_comboBox.Location = new System.Drawing.Point(270, 66);
            this.RemoveMajorCourses_Term_comboBox.Name = "RemoveMajorCourses_Term_comboBox";
            this.RemoveMajorCourses_Term_comboBox.Size = new System.Drawing.Size(121, 21);
            this.RemoveMajorCourses_Term_comboBox.TabIndex = 24;
            this.RemoveMajorCourses_Term_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_Term_comboBox_SelectedIndexChanged);
            // 
            // RemoveMajorCourses_Discipline_comboBox
            // 
            this.RemoveMajorCourses_Discipline_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_Discipline_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_Discipline_comboBox.Location = new System.Drawing.Point(81, 12);
            this.RemoveMajorCourses_Discipline_comboBox.Name = "RemoveMajorCourses_Discipline_comboBox";
            this.RemoveMajorCourses_Discipline_comboBox.Size = new System.Drawing.Size(499, 21);
            this.RemoveMajorCourses_Discipline_comboBox.TabIndex = 20;
            this.RemoveMajorCourses_Discipline_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_Discipline_comboBox_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(413, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "Year :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(224, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 18;
            this.label5.Text = "Term :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "Credit :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(192, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 16;
            this.label3.Text = "Course Title : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "Course Code :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Discipline : ";
            // 
            // RemoveMajorCourses_CourseCode_comboBox
            // 
            this.RemoveMajorCourses_CourseCode_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_CourseCode_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_CourseCode_comboBox.Location = new System.Drawing.Point(81, 38);
            this.RemoveMajorCourses_CourseCode_comboBox.Name = "RemoveMajorCourses_CourseCode_comboBox";
            this.RemoveMajorCourses_CourseCode_comboBox.Size = new System.Drawing.Size(105, 21);
            this.RemoveMajorCourses_CourseCode_comboBox.TabIndex = 28;
            this.RemoveMajorCourses_CourseCode_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_CourseCode_comboBox_SelectedIndexChanged);
            // 
            // RemoveMajorCourses_CourseTitle_comboBox
            // 
            this.RemoveMajorCourses_CourseTitle_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_CourseTitle_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_CourseTitle_comboBox.Location = new System.Drawing.Point(270, 39);
            this.RemoveMajorCourses_CourseTitle_comboBox.Name = "RemoveMajorCourses_CourseTitle_comboBox";
            this.RemoveMajorCourses_CourseTitle_comboBox.Size = new System.Drawing.Size(308, 21);
            this.RemoveMajorCourses_CourseTitle_comboBox.TabIndex = 29;
            this.RemoveMajorCourses_CourseTitle_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_CourseTitle_comboBox_SelectedIndexChanged);
            // 
            // RemoveMajorCourses_Credit_comboBox
            // 
            this.RemoveMajorCourses_Credit_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.RemoveMajorCourses_Credit_comboBox.FormattingEnabled = true;
            this.RemoveMajorCourses_Credit_comboBox.Items.AddRange(new object[] {
            "6",
            "5",
            "4",
            "3",
            "2",
            "1.5",
            "1",
            "1.25",
            "1",
            ".75",
            ".5"});
            this.RemoveMajorCourses_Credit_comboBox.Location = new System.Drawing.Point(82, 66);
            this.RemoveMajorCourses_Credit_comboBox.Name = "RemoveMajorCourses_Credit_comboBox";
            this.RemoveMajorCourses_Credit_comboBox.Size = new System.Drawing.Size(104, 21);
            this.RemoveMajorCourses_Credit_comboBox.TabIndex = 30;
            this.RemoveMajorCourses_Credit_comboBox.SelectedIndexChanged += new System.EventHandler(this.RemoveMajorCourses_Credit_comboBox_SelectedIndexChanged);
            // 
            // RemoveMajorCourses
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(590, 160);
            this.Controls.Add(this.RemoveMajorCourses_Credit_comboBox);
            this.Controls.Add(this.RemoveMajorCourses_CourseTitle_comboBox);
            this.Controls.Add(this.RemoveMajorCourses_CourseCode_comboBox);
            this.Controls.Add(this.RemoveMajorCourses_Save_button);
            this.Controls.Add(this.RemoveMajorCourses_Cancel_button);
            this.Controls.Add(this.RemoveMajorCourses_Year_comboBox);
            this.Controls.Add(this.RemoveMajorCourses_Term_comboBox);
            this.Controls.Add(this.RemoveMajorCourses_Discipline_comboBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "RemoveMajorCourses";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Remove A Major Courses of Your Discipline";
            this.Load += new System.EventHandler(this.RemoveMajorCourses_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RemoveMajorCourses_Save_button;
        private System.Windows.Forms.Button RemoveMajorCourses_Cancel_button;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_Year_comboBox;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_Term_comboBox;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_Discipline_comboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_CourseCode_comboBox;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_CourseTitle_comboBox;
        private System.Windows.Forms.ComboBox RemoveMajorCourses_Credit_comboBox;
    }
}